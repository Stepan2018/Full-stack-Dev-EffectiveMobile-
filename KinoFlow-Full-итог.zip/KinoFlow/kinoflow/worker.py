"""Process durable PostgreSQL upload jobs independently of HTTP requests."""
import logging
import subprocess
import time

from media import InvalidShort, transcode
from server import MEDIA, connect, file_digest, query, save_video

log = logging.getLogger("kinoflow.worker")


def process_one():
    conn = connect()
    try:
        with conn, conn.cursor() as cursor:
            job = query(cursor, """
                SELECT * FROM upload_jobs WHERE status='processing'
                ORDER BY created,id LIMIT 1 FOR UPDATE SKIP LOCKED
            """)
            if not job:
                return False
            folder = MEDIA / job["id"]
            raw = folder / "upload"
            try:
                duration = transcode(raw, job["is_short"])
                digest = file_digest(folder / "video.mp4")
            except (InvalidShort, ValueError, ArithmeticError, subprocess.SubprocessError, OSError) as error:
                message = str(error) if isinstance(error, InvalidShort) else "Не удалось обработать видео. Проверьте формат файла."
                cursor.execute("UPDATE upload_jobs SET status='failed',error=%s WHERE id=%s", (message, job["id"]))
                cleanup = ("upload", "video.mp4", "poster.jpg")
                log.warning("Upload %s failed: %s", job["id"], type(error).__name__)
            else:
                matches = save_video(cursor, job["id"], job["title"], job["description"], job["private"], job["owner"],
                                     job["is_short"], duration, job["source_sha256"], digest)
                cursor.execute("UPDATE upload_jobs SET status='ready',copyright_matches=%s WHERE id=%s",
                               (matches, job["id"]))
                cleanup = ("upload",)
        for name in cleanup:
            try:
                (folder / name).unlink(missing_ok=True)
            except OSError:
                log.warning("Could not remove %s for %s", name, job["id"])
        return True
    finally:
        conn.close()


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    while True:
        try:
            if not process_one():
                time.sleep(1)
        except Exception:
            log.exception("Worker iteration failed; the transaction will be retried")
            time.sleep(3)
