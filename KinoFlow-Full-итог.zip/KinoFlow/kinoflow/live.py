import asyncio
import json
import secrets
from dataclasses import dataclass, field

from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from starlette.concurrency import run_in_threadpool

router = APIRouter(prefix="/api/live", tags=["Эфиры"])


@dataclass
class Room:
    id: str
    title: str
    owner: int
    author: str
    host: WebSocket
    viewers: dict = field(default_factory=dict)


rooms: dict[str, Room] = {}


@router.get("")
async def live_list():
    return [{"id": room.id, "title": room.title, "owner": room.owner,
             "author": room.author, "viewers": len(room.viewers)} for room in rooms.values()]


async def send(socket, data):
    try:
        await asyncio.wait_for(socket.send_json(data), 3)
        return True
    except (TimeoutError, RuntimeError, OSError, WebSocketDisconnect):
        return False


async def close(socket, code=1000):
    try:
        await asyncio.wait_for(socket.close(code=code), 3)
    except (TimeoutError, RuntimeError, OSError, WebSocketDisconnect):
        pass


async def account(socket):
    origin = socket.headers.get("origin")
    scheme = "https" if socket.url.scheme == "wss" else "http"
    if origin != f"{scheme}://{socket.url.netloc}":
        await close(socket, 1008)
        return None
    user = await run_in_threadpool(socket.app.state.live_account, socket.cookies.get("session"))
    if not user:
        await close(socket, 1008)
    return user


async def signal(socket):
    while True:
        event = await socket.receive()
        if event["type"] == "websocket.disconnect":
            raise WebSocketDisconnect(event.get("code", 1000))
        text = event.get("text")
        if text is None:
            return None
        if len(text) > 48_000:
            return None
        try:
            data = json.loads(text)
        except ValueError:
            continue
        if isinstance(data, dict):
            return data


@router.websocket("/host")
async def host(socket: WebSocket):
    user = await account(socket)
    if not user:
        return
    title = socket.query_params.get("title", "").strip()
    if not title or len(title) > 120 or len(rooms) >= 32 or any(r.owner == user["id"] for r in rooms.values()):
        await socket.accept()
        await send(socket, {"type": "error", "message": "Проверьте название или завершите предыдущий эфир."})
        await close(socket, 1008)
        return
    room = Room(secrets.token_hex(16), title, user["id"], user["name"], socket)
    rooms[room.id] = room
    try:
        await socket.accept()
        if not await send(socket, {"type": "ready", "room": room.id}):
            return
        while data := await signal(socket):
            if data.get("type") == "end":
                break
            peer_id = data.get("peer")
            peer = room.viewers.get(peer_id) if isinstance(peer_id, str) else None
            kind = data.get("type")
            payload = data.get("data")
            if peer and kind in ("offer", "ice") and isinstance(payload, dict):
                await send(peer, {"type": kind, "data": payload})
    except WebSocketDisconnect:
        pass
    finally:
        rooms.pop(room.id, None)
        peers = list(room.viewers.values())
        await asyncio.gather(*(send(peer, {"type": "ended"}) for peer in peers))
        await asyncio.gather(*(close(peer) for peer in peers))
        await close(socket)


@router.websocket("/watch/{room_id}")
async def watch(socket: WebSocket, room_id: str):
    if not await account(socket):
        return
    room = rooms.get(room_id)
    if not room or len(room.viewers) >= 8:
        await socket.accept()
        await send(socket, {"type": "error", "message": "Эфир завершён или все места заняты."})
        await close(socket, 1008)
        return
    peer = secrets.token_hex(12)
    room.viewers[peer] = socket
    try:
        await socket.accept()
        if not await send(room.host, {"type": "join", "peer": peer}):
            await send(socket, {"type": "ended"})
            return
        while data := await signal(socket):
            kind = data.get("type")
            payload = data.get("data")
            if kind in ("answer", "ice") and isinstance(payload, dict):
                await send(room.host, {"type": kind, "peer": peer, "data": payload})
    except WebSocketDisconnect:
        pass
    finally:
        room.viewers.pop(peer, None)
        await send(room.host, {"type": "leave", "peer": peer})
        await close(socket)
