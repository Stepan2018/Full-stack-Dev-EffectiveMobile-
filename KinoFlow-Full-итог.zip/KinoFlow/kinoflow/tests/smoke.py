"""Black-box checks against a disposable KinoFlow deployment."""
import argparse
import json
import secrets
import subprocess
import sys
import unittest
from http.cookiejar import CookieJar
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import HTTPCookieProcessor, Request, build_opener

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from demo import register, wait_for_video


class Smoke(unittest.TestCase):
    def request(self, client, path, data=None, status=200, headers=None):
        headers = dict(headers or {})
        if isinstance(data, dict):
            headers["Content-Type"] = "application/json"
            data = json.dumps(data).encode()
        try:
            response = client.open(Request(self.base + path, data, headers), timeout=20)
        except HTTPError as error:
            response = error
        with response:
            body = response.read()
            self.assertEqual(response.status, status, (path, body[:300]))
            return json.loads(body) if response.headers.get_content_type() == "application/json" else body

    def test_upload_to_comment_and_private_access(self):
        guest, owner, viewer = [build_opener(HTTPCookieProcessor(CookieJar())) for _ in range(3)]
        self.assertEqual(self.request(guest, "/api/health"), {"status": "ok"})
        self.assertIn("/api/uploads/{video_id}", self.request(guest, "/openapi.json")["paths"])
        self.assertIn(b"Swagger UI", self.request(guest, "/docs"))
        name, password = register(owner, self.base + "/api", "qa-author")
        viewer_name, _ = register(viewer, self.base + "/api", "qa-viewer")
        self.request(owner, "/api/logout", {})
        self.request(owner, "/api/login", {"name": name, "password": password})

        mp4 = subprocess.check_output([
            "ffmpeg", "-v", "error", "-f", "lavfi", "-i", "color=s=160x90:r=12:d=2",
            "-c:v", "libx264", "-threads", "1", "-pix_fmt", "yuv420p",
            "-movflags", "+frag_keyframe+empty_moov", "-f", "mp4", "pipe:1",
        ])
        title = "Smoke-" + secrets.token_hex(6)
        job = self.request(owner, "/api/upload?title=" + title + "&private=true", mp4, 202)
        video_id = job["id"]
        self.assertEqual(job["status"], "processing")
        self.request(viewer, "/api/uploads/" + video_id, status=404)
        self.assertEqual(wait_for_video(owner, self.base + "/api", video_id)["status"], "ready")

        video = "/api/videos/" + video_id
        self.request(guest, video, status=404)
        self.request(viewer, video + "/poster", status=404)
        self.request(viewer, video + "/stream", status=404, headers={"Range": "bytes=0-127"})
        self.request(owner, video + "/access", {"name": viewer_name, "enabled": True})
        self.assertTrue(self.request(viewer, video + "/poster").startswith(b"\xff\xd8"))
        chunk = self.request(viewer, video + "/stream", status=206, headers={"Range": "bytes=0-127"})
        self.assertEqual(len(chunk), 128)
        self.assertEqual(self.request(viewer, "/api/videos?q=" + title)[0]["id"], video_id)
        self.request(viewer, video + "/like", {"enabled": True})
        self.request(viewer, video + "/comment", {"body": "Проверка публикации"})
        result = self.request(viewer, video)
        self.assertTrue(result["liked"])
        self.assertTrue(any(comment["body"] == "Проверка публикации" for comment in result["comments"]))
        self.request(viewer, "/api/moderation", status=403)
        self.request(owner, video + "/access", {"name": viewer_name, "enabled": False})
        self.request(viewer, video + "/stream", status=404)

        invalid = self.request(owner, "/api/upload?title=Invalid", b"invalid media", 202)["id"]
        with self.assertRaisesRegex(RuntimeError, "Не удалось обработать видео"):
            wait_for_video(owner, self.base + "/api", invalid)
        self.request(owner, "/api/videos/" + invalid, status=404)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base", default="http://127.0.0.1:8000")
    Smoke.base = parser.parse_args().base.rstrip("/")
    unittest.main(argv=[sys.argv[0]], verbosity=2)
