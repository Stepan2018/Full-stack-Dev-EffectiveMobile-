"use strict";
const main = document.querySelector("#main");
const nav = document.querySelector("#navigation");
const search = document.querySelector("#search");
const toast = document.querySelector("#toast");
const account = document.querySelector("#account");
let user, revision = 0, timer, flushPlayback, closeLive;
const themeButton = document.querySelector("#theme");
function applyTheme(theme) {
  document.documentElement.dataset.theme = theme;
  themeButton.textContent = theme === "dark" ? "☀" : "☾";
  themeButton.setAttribute("aria-pressed", String(theme === "dark"));
}
applyTheme(localStorage.getItem("kino-theme") || (matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light"));
themeButton.addEventListener("click", () => {
  const theme = document.documentElement.dataset.theme === "dark" ? "light" : "dark";
  localStorage.setItem("kino-theme", theme);
  applyTheme(theme);
});
window.addEventListener("pagehide", () => { flushPlayback?.(); closeLive?.(); });
const esc = value => String(value ?? "").replace(/[&<>"']/g, char =>
  ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char]);
const url = id => "/api/videos/" + id;
const watch = id => "#/watch/" + id;
const shortWatch = id => "#/shorts/" + id;
const videoLink = v => v.is_short ? shortWatch(v.id) : watch(v.id);
const channel = id => "#/channel/" + id;
const profileLink = name => "#/u/" + encodeURIComponent(name);
const folders = { saved: "Сохранённые видео", later: "Посмотреть позже", own: "Ваши видео",
  liked: "Понравившиеся", commented: "Видео с вашими комментариями" };
const date = seconds => new Date(seconds * 1000).toLocaleDateString("ru-RU");

async function api(path, data) {
  const response = await fetch("/api" + path, data === undefined ? {} : {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data)
  });
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || "Ошибка запроса");
  return result;
}

function notify(message) {
  toast.textContent = message;
  toast.hidden = false;
  clearTimeout(timer);
  timer = setTimeout(() => { toast.hidden = true; }, 4000);
}

function authLink() {
  return '<a class="button" href="#/login">Войти</a>';
}

function chrome(path) {
  const item = (href, label, icon) =>
    `<a href="${href}" ${(href === "#" + path || (href === "#/shorts" && path.startsWith("/shorts/"))) ? 'aria-current="page"' : ""}><span aria-hidden="true">${icon}</span>${label}</a>`;
  nav.innerHTML = item("#/", "Главная", "⌂") + item("#/shorts", "Shorts", "▷") + item("#/live", "Эфиры", "◉") +
    item("#/recommendations", "Рекомендации", "✦") + item("#/subscriptions", "Подписки", "▤") + item("#/upload", "Загрузить", "↑") +
    item("#/profile", "Профиль", "◉") +
    (user && user.role !== "user" ? item("#/moderation", "Модерация", "⚑") : "") +
    (user?.role === "admin" ? item("#/users", "Роли", "♙") : "") +
    '<small>ЛОКАЛЬНАЯ ВИДЕОПЛАТФОРМА</small>';
  account.innerHTML = user
    ? `<a class="button notification-link" href="#/notifications" aria-label="Уведомления">🔔<span hidden></span></a><a class="avatar" href="#/profile" title="Профиль: ${esc(user.name)}">${esc(user.name[0].toUpperCase())}</a>
       <button id="logout" class="quiet">Выйти</button>`
    : authLink();
  const bell = account.querySelector(".notification-link");
  if (bell && path !== "/notifications") api("/notifications").then(data => {
    if (bell.isConnected) updateBell(data.unread);
  }).catch(() => {});
  account.querySelector("#logout")?.addEventListener("click", async () => {
    try {
      await flushPlayback?.();
      closeLive?.();
      await api("/logout", {});
      user = null;
      if (location.hash === "#/") render();
      else location.hash = "#/";
    } catch (error) { notify(error.message); }
  });
}

function updateBell(unread) {
  const bell = account.querySelector(".notification-link");
  if (!bell) return;
  const badge = bell.querySelector("span");
  badge.hidden = !unread;
  badge.textContent = unread || "";
  bell.setAttribute("aria-label", unread ? `Уведомления · новых: ${unread}` : "Уведомления");
}

function videoTime(seconds) {
  const whole = Math.floor(seconds);
  const minutes = Math.floor(whole / 60);
  return minutes + ":" + String(whole % 60).padStart(2, "0");
}

function grid(videos, empty = "Пока здесь нет видео") {
  if (!videos.length) return `<div class="empty">${esc(empty)}</div>`;
  return `<div class="grid">${videos.map(v => `
    <article class="card">
      <a class="thumb" href="${videoLink(v)}">
        <img src="${url(v.id)}/poster" alt="${esc(v.title)}" loading="lazy">
        ${v.private ? '<span class="badge visibility-badge">Приватное</span>' : ""}
        ${v.duration_seconds ? `<span class="badge">${videoTime(v.duration_seconds)}</span>` : ""}
      </a>
      <div class="card-body">
        <a class="avatar" href="${channel(v.owner)}" aria-label="Канал ${esc(v.author)}">${esc(v.author[0].toUpperCase())}</a>
        <div><a class="card-title" href="${videoLink(v)}">${esc(v.title)}</a>
        <a class="muted" href="${channel(v.owner)}">${esc(v.author)}</a>
        <small>${date(v.created)}</small></div>
      </div>
    </article>`).join("")}</div>`;
}

function shortsGrid(videos, empty = "Коротких роликов пока нет.") {
  if (!videos.length) return `<div class="empty">${esc(empty)}</div>`;
  return `<div class="shorts-grid">${videos.map(v => `
    <a class="short-card" href="${shortWatch(v.id)}">
      <img src="${url(v.id)}/poster" alt="" loading="lazy">
      <span class="short-label">${v.private ? "Приватное" : "Shorts"}</span>
      <span class="short-caption"><strong>${esc(v.title)}</strong><small>${esc(v.author)}</small></span>
    </a>`).join("")}</div>`;
}

function shortsPage(items) {
  main.innerHTML = `<div class="shorts-heading"><div><div class="eyebrow">K I N O F L O W</div>
    <h1>Shorts</h1><p class="muted">Вертикальные видео до 60 секунд</p></div>
    <a class="button" href="#/upload?format=short">↑ Загрузить Shorts</a></div>${shortsGrid(items)}`;
}

function subscriptionsPage(data) {
  const fresh = new Set(data.new_ids);
  main.innerHTML = `<section><div class="eyebrow">ВАШИ КАНАЛЫ</div><h1>Подписки</h1>
    ${data.channels.length ? `<div class="subscription-channels" role="group" aria-label="Каналы">
    <button type="button" data-channel="" aria-pressed="true"><span class="avatar large">▤</span><span>Все каналы</span></button>
    ${data.channels.map(c => `<button type="button" data-channel="${c.id}" aria-pressed="false"
      aria-label="${esc(c.name)}${c.new_count ? ` · новых: ${c.new_count}` : ""}">
      <span class="subscription-icon"><span class="avatar large">${c.has_avatar
        ? `<img src="${imageUrl(c.id, "avatar")}" alt="">` : esc(c.name[0].toUpperCase())}</span>
      ${c.new_count ? '<span class="subscription-dot" aria-hidden="true"></span>' : ""}</span>
      <span>${esc(c.name)}</span></button>`).join("")}</div>
    <div class="actions subscription-filters" role="group" aria-label="Фильтр публикаций">
      ${Object.entries({all:"Все", fresh:"Новые", video:"Видео", short:"Shorts"}).map(([key,label]) =>
        `<button data-feed="${key}" aria-pressed="${key === "all"}">${label}</button>`).join("")}
    </div>
    <div id="subscription-feed"></div>` : '<div class="empty">Подпишитесь на каналы, чтобы увидеть их публикации. <a class="accent" href="#/recommendations">Найти видео</a></div>'}
  </section>`;
  if (!data.channels.length) return;
  let selected = "";
  let filter = "all";
  const feed = main.querySelector("#subscription-feed");
  function updateFeed() {
    const items = data.videos.filter(video => {
      if (selected && String(video.owner) !== selected) return false;
      if (filter === "fresh") return fresh.has(video.id);
      if (filter === "video") return !video.is_short;
      if (filter === "short") return video.is_short;
      return true;
    });
    feed.innerHTML = (selected ? `<a class="accent subscription-open" href="${channel(selected)}">Открыть канал →</a>` : "") +
      (filter === "short" ? shortsGrid(items, "В этом разделе пока нет Shorts")
        : grid(items, "В этом разделе пока нет публикаций"));
  }
  main.querySelectorAll("[data-channel], [data-feed]").forEach(button => {
    button.addEventListener("click", () => {
      const attribute = button.hasAttribute("data-channel") ? "channel" : "feed";
      if (attribute === "channel") selected = button.dataset.channel;
      else filter = button.dataset.feed;
      for (const item of main.querySelectorAll("[data-" + attribute + "]")) {
        item.setAttribute("aria-pressed", String(item === button));
      }
      updateFeed();
    });
  });
  updateFeed();
}

function searchPage(items, channels, params) {
  const q = params.get("q") || "";
  const filters = {
    format: ["Формат", {all:"Все", video:"Видео", short:"Shorts"}],
    days: ["Дата публикации", {all:"За всё время", 1:"За сутки", 7:"За неделю", 30:"За месяц"}],
    length: ["Длительность", {all:"Любая", under4:"До 4 минут", "4to20":"От 4 до 20 минут", over20:"Дольше 20 минут"}]
  };
  main.innerHTML = `<div class="eyebrow">ПОИСК</div><h1>${q ? "Результаты по запросу «" + esc(q) + "»" : "Все видео"}</h1>
    <form id="search-filters" class="actions search-filters">${Object.entries(filters).map(([key,[label,values]]) =>
      `<label>${label}<select name="${key}">${Object.entries(values).map(([value,text]) =>
        `<option value="${value}" ${(params.get(key) || "all") === value ? "selected" : ""}>${text}</option>`).join("")}</select></label>`).join("")}
    <button class="button">Применить</button></form>
    ${channels.length ? `<h2>Каналы</h2><div class="actions">${channels.map(c =>
      `<a class="button" href="${channel(c.id)}">@${esc(c.name)}</a>`).join("")}</div><h2>Видео</h2>` : ""}
    ${grid(items, "Видео по этому запросу не найдены")}`;
  wireForm("search-filters", data => { location.hash = "#/search?" + new URLSearchParams({ q, ...data }); });
}

function notificationsPage(data) {
  updateBell(data.unread);
  const unread = new Set(data.unread_ids);
  main.innerHTML = `<div class="actions notification-title"><h1>Уведомления</h1>
    ${data.unread ? '<button id="mark-notifications">Отметить все прочитанными</button>' : ""}</div>
    <p class="muted">Новые видео и Shorts каналов, для которых включены уведомления.</p>
    ${data.videos.length ? `<div class="notification-list">${data.videos.map(video =>
      `<a class="notification-row ${unread.has(video.id) ? "unread" : ""}" data-notification="${video.id}" href="${videoLink(video)}">
        <img src="${url(video.id)}/poster" alt="" loading="lazy">
        <span><strong>${esc(video.title)}</strong><small>${esc(video.author)} · ${date(video.created)}
        ${unread.has(video.id) ? " · Новое" : ""}</small></span></a>`).join("")}</div>`
      : '<div class="empty">Пока нет уведомлений. <a class="accent" href="#/subscriptions">Открыть подписки</a></div>'}`;
  wireButton("mark-notifications", async () => {
    await api("/notifications/read", {ids: data.unread_ids});
    await refresh();
  });
  main.querySelectorAll(".notification-row.unread").forEach(link => {
    link.addEventListener("click", () => api("/notifications/read", {ids: [link.dataset.notification]})
      .then(() => api("/notifications")).then(current => updateBell(current.unread)).catch(() => {}));
  });
}

function uuid() {
  const bytes = crypto.getRandomValues(new Uint8Array(16));
  bytes[6] = (bytes[6] & 15) | 64;
  bytes[8] = (bytes[8] & 63) | 128;
  const hex = Array.from(bytes, byte => byte.toString(16).padStart(2, "0")).join("");
  return [hex.slice(0,8), hex.slice(8,12), hex.slice(12,16), hex.slice(16,20), hex.slice(20)].join("-");
}

function trackPlayback(video, item, viewer) {
  const session_id = uuid();
  const endpoint = url(item.id) + "/progress";
  let sequence = 0, watched = 0, lastTime, lastTick, lastSent = 0, started = false;
  function sample() {
    const now = performance.now();
    const position = video.currentTime;
    if (lastTime !== undefined && !video.seeking && position > lastTime) {
      const wall = (now - lastTick) / 1000;
      const media = (position - lastTime) / video.playbackRate;
      if (media <= wall + 0.35) watched += Math.min(media, wall);
    }
    lastTime = position;
    lastTick = now;
  }
  function flush(ended = video.ended) {
    if (!started) return;
    lastSent = performance.now();
    return fetch(endpoint, {method:"POST", keepalive:true, headers:{"Content-Type":"application/json"},
      body:JSON.stringify({ viewer, session_id, sequence:++sequence,
        position:ended ? 0 : Math.min(86400,video.currentTime), watched:Math.min(86400,watched) })
    }).catch(() => {});
  }
  video.addEventListener("playing", () => {
    lastTime = undefined;
    sample();
    if (!started) {
      started = true;
      flush();
    }
  });
  video.addEventListener("timeupdate", () => {
    if (video.paused || !started) return;
    sample();
    if (performance.now() - lastSent >= 5000) flush();
  });
  for (const event of ["seeking", "waiting", "ratechange"]) {
    video.addEventListener(event, () => { lastTime = undefined; });
  }
  video.addEventListener("pause", () => {
    sample();
    lastTime = undefined;
    flush();
  });
  video.addEventListener("ended", () => flush(true));
  return () => {
    if (!video.paused) sample();
    return flush();
  };
}

function form(id, html, label, extra = "") {
  return `<form id="${id}" class="fields">${html}<div class="actions"><button class="primary">${label}</button>${extra}</div></form>`;
}

function input(name, label, max, type = "text", attrs = "") {
  return `<label>${label}<input name="${name}" type="${type}" maxlength="${max}" required ${attrs}></label>`;
}

function wireForm(id, handler) {
  main.querySelector("#" + id)?.addEventListener("submit", async event => {
    event.preventDefault();
    const target = event.currentTarget;
    const submit = event.submitter;
    if (submit) submit.disabled = true;
    try {
      await handler(Object.fromEntries(new FormData(target)), submit, target);
    } catch (error) {
      notify(error.message);
    } finally {
      if (submit) submit.disabled = false;
    }
  });
}

function wireButton(id, handler) {
  main.querySelector("#" + id)?.addEventListener("click", async event => {
    const button = event.currentTarget;
    button.disabled = true;
    try { await handler(); }
    catch (error) { notify(error.message); }
    finally { button.disabled = false; }
  });
}

function refresh() { return render(true); }

function authPage(register) {
  const title = register ? "Создать аккаунт" : "Вход";
  main.innerHTML = `<section class="panel compact"><div class="eyebrow">АККАУНТ</div><h1>${title}</h1>` +
    form("auth", input("name", "Имя пользователя", 32, "text", 'autocomplete="username"') +
      input("password", "Пароль", 128, "password", register ? 'minlength="8" autocomplete="new-password"' : 'autocomplete="current-password"'),
      register ? "Зарегистрироваться" : "Войти") +
    `<a class="accent" href="#/${register ? "login" : "register"}">${register ? "Уже есть аккаунт?" : "Создать аккаунт"}</a></section>`;
  wireForm("auth", async data => {
    user = await api(register ? "/register" : "/login", data);
    location.hash = "#/profile";
  });
}

function uploadPage(short = false) {
  main.innerHTML = `<section class="panel compact"><div class="eyebrow">СТУДИЯ АВТОРА</div><h1>Загрузить видео</h1>` +
    (user ? form("upload", '<label class="drop">Видеофайл · до 100 МБ<input name="file" type="file" accept="video/*" required></label>' +
      input("title", "Название", 120) +
      '<label>Описание<textarea name="description" maxlength="2000" rows="4"></textarea></label>' +
      `<label>Формат<select name="is_short"><option value="0">Обычное видео</option><option value="1" ${short ? "selected" : ""}>Shorts · вертикальное, до 60 секунд</option></select></label>` +
      '<label>Доступ<select name="private"><option value="0">Публичное</option><option value="1">Приватное</option></select></label>' +
      '<progress max="100" value="0" hidden aria-label="Ход загрузки"></progress><output></output>', "Опубликовать")
      : '<p>Войдите, чтобы загрузить видео.</p>' + authLink()) + '</section>';
  wireForm("upload", async (data, button, target) => {
    const { file, ...meta } = data;
    if (!file.size || file.size > 100 * 1024 * 1024) throw new Error("Выберите видео размером до 100 МБ");
    const progress = target.querySelector("progress");
    const status = target.querySelector("output");
    progress.hidden = false;
    progress.value = 0;
    status.textContent = "Отправка файла…";
    try {
      let result = await new Promise((resolve, reject) => {
        const xhr = new XMLHttpRequest();
        xhr.open("POST", "/api/upload?" + new URLSearchParams(meta));
        xhr.responseType = "json";
        xhr.upload.onprogress = event => {
          if (event.lengthComputable) progress.value = event.loaded / event.total * 100;
        };
        xhr.upload.onload = () => {
          progress.removeAttribute("value");
          status.textContent = "Файл получен. Готовим видео и превью…";
        };
        xhr.onload = () => xhr.status === 202 ? resolve(xhr.response) :
          reject(new Error(xhr.response?.error || "Загрузка завершилась ошибкой"));
        xhr.onerror = () => reject(new Error("Соединение прервано"));
        xhr.send(file);
      });
      status.textContent = "Видео в очереди. Можно перейти на другую страницу.";
      while (target.isConnected && result.status === "processing") {
        await new Promise(resolve => setTimeout(resolve, 1200));
        if (!target.isConnected) return;
        result = await api("/uploads/" + result.id);
      }
      if (result.status === "failed") throw new Error(result.error);
      if (target.isConnected) {
        if (result.copyright_matches) notify("Обнаружено совпадение с эталоном. Подробности в студии.");
        location.hash = meta.is_short === "1" ? shortWatch(result.id) : watch(result.id);
      }
    } catch (error) {
      progress.hidden = true;
      status.textContent = "";
      throw error;
    }
  });
}

function watchPage(v, playback, queue = null) {
  const mine = v.owner === user?.id;
  const index = queue?.findIndex(item => item.id === v.id) ?? -1;
  const previous = index > 0 ? queue[index - 1] : null;
  const next = index >= 0 ? queue[index + 1] : null;
  main.innerHTML = `<section class="watch ${queue ? "short-watch" : ""}">
    ${queue ? '<a class="accent short-back" href="#/shorts">← Все Shorts</a>' : ""}
    <video controls playsinline ${queue && !playback ? "autoplay muted" : ""} preload="metadata" poster="${url(v.id)}/poster" src="${url(v.id)}/stream"></video>
    ${queue ? `<div class="short-controls">
      ${previous ? `<a class="button" href="${shortWatch(previous.id)}" aria-label="Предыдущий ролик">↑</a>` : '<button disabled aria-label="Предыдущий ролик">↑</button>'}
      <span class="muted">${index + 1} / ${queue.length}</span>
      ${next ? `<a class="button" href="${shortWatch(next.id)}" aria-label="Следующий ролик">↓</a>` : '<button disabled aria-label="Следующий ролик">↓</button>'}
    </div>` : ""}
    <h1>${esc(v.title)}</h1>
    <div class="watchbar"><a class="creator" href="${channel(v.owner)}"><span class="avatar">${esc(v.author[0].toUpperCase())}</span>${esc(v.author)}</a>
    <div class="actions"><button id="like" aria-pressed="${v.liked}">♥ ${v.likes}</button>
    ${user ? `<button id="saved" aria-pressed="${v.folders?.includes("saved") || false}">Сохранить</button>
    <button id="later" aria-pressed="${v.folders?.includes("later") || false}">Посмотреть позже</button>` : ""}
    ${user && !mine && v.support_enabled ? '<button id="demo-tip">Поддержать · 10 демо-баллов</button>' : ""}
    ${user && !mine ? '<button id="report-open">Пожаловаться</button>' : ""}</div></div>
    <div class="description"><small>${date(v.created)} ${v.private ? "· Приватное видео" : ""}</small><p>${esc(v.description)}</p></div>
    ${user && !mine ? '<section id="report-box" hidden>' + form("report", input("reason", "Причина жалобы", 500), "Отправить жалобу") + '</section>' : ""}
    ${mine && v.private ? `<section class="panel"><h2>Доступ к видео</h2><p class="muted">${v.grants.length ? esc(v.grants.join(", ")) : "Доступ есть только у вас."}</p>` +
      form("access", input("name", "Имя пользователя", 32), "Разрешить", '<button name="remove">Отозвать</button>') + '</section>' : ""}
    <section class="comments"><h2>Комментарии · ${v.comments.length}</h2>
    ${user ? form("comment", input("body", "Ваш комментарий", 1000), "Опубликовать") : '<p><a class="accent" href="#/login">Войдите</a>, чтобы оставить комментарий.</p>'}
    ${v.comments.map(c => `<article class="comment"><strong>${esc(c.name)}</strong><p>${esc(c.body)}</p></article>`).join("")}</section></section>`;
  const video = main.querySelector("video");
  if (user) {
    if (!playback && v.position_seconds > 0) {
      video.addEventListener("loadedmetadata", () => {
        if (v.position_seconds < video.duration) video.currentTime = v.position_seconds;
      }, {once:true});
    }
    flushPlayback = trackPlayback(video, v, user.id);
    for (const folder of ["saved", "later"]) {
      wireButton(folder, async () => {
        const button = main.querySelector("#" + folder);
        const enabled = button.getAttribute("aria-pressed") !== "true";
        await api("/videos/" + v.id + "/library/" + folder, { enabled });
        button.setAttribute("aria-pressed", String(enabled));
        notify(enabled ? "Добавлено в библиотеку" : "Удалено из библиотеки");
      });
    }
  }
  if (queue) {
    let start;
    video.addEventListener("touchstart", event => {
      start = event.touches.length === 1 ? event.touches[0] : null;
    }, { passive: true });
    video.addEventListener("touchend", event => {
      if (!start) return;
      const end = event.changedTouches[0];
      const dy = end.clientY - start.clientY;
      const dx = end.clientX - start.clientX;
      start = null;
      if (Math.abs(dy) < 55 || Math.abs(dy) < Math.abs(dx) * 1.5) return;
      const target = dy < 0 ? next : previous;
      if (target) location.hash = shortWatch(target.id);
    });
  }
  if (playback) video.addEventListener("loadedmetadata", () => {
    video.currentTime = playback.time;
    video.muted = playback.muted;
    if (playback.playing) video.play().catch(() => {});
  }, { once: true });
  let tipRequest;
  wireButton("demo-tip", async () => {
    tipRequest ||= uuid();
    const result = await api("/videos/" + v.id + "/support", {amount:10,request_id:tipRequest});
    tipRequest = null;
    notify("Отправлено 10 демо-баллов. Остаток: " + result.balance);
  });
  const update = async (action, data) => { await api("/videos/" + v.id + "/" + action, data); };
  wireButton("like", async () => {
    if (!user) return notify("Войдите, чтобы поставить лайк");
    await update("like", { enabled: !v.liked });
    v.liked = !v.liked;
    v.likes += v.liked ? 1 : -1;
    const button = main.querySelector("#like");
    if (button && video.isConnected) {
      button.textContent = "♥ " + v.likes;
      button.setAttribute("aria-pressed", v.liked);
    }
  });
  wireButton("report-open", () => { main.querySelector("#report-box").hidden = false; });
  wireForm("report", async (data, button, target) => {
    await update("report", data);
    target.reset();
    target.parentElement.hidden = true;
    notify("Жалоба отправлена");
  });
  wireForm("comment", async data => { await update("comment", data); if (video.isConnected) await refresh(); });
  wireForm("access", async (data, button) => {
    await update("access", { ...data, enabled: button?.name !== "remove" });
    if (video.isConnected) await refresh();
  });
}

function imageUrl(userId, kind) {
  return `/api/profiles/${userId}/image/${kind}`;
}

function profileHeader(person, images, tools = "") {
  return `<section class="profile-header">
    ${tools}
    <div class="profile-cover">${images.includes("cover") ? `<img src="${imageUrl(person.id, "cover")}" alt="">` : ""}</div>
    <div class="profile-identity">
      <span class="avatar large profile-avatar">${images.includes("avatar")
        ? `<img src="${imageUrl(person.id, "avatar")}" alt="">` : esc(person.name[0].toUpperCase())}</span>
      <div><h1>${esc(person.name)}</h1><a class="accent" href="${profileLink(person.name)}">@${esc(person.name)}</a></div>
    </div>
  </section>`;
}

function accountsPage(items) {
  main.innerHTML = `<section class="panel compact"><h1>Аккаунты</h1>
    <p class="muted">Аккаунты, в которые выполнен вход в этом браузере.</p>
    <div class="account-list">${items.map(item =>
      `<button id="switch-${item.id}" ${item.id === user?.id ? 'disabled aria-current="true"' : ""}>
        @${esc(item.name)} ${item.id === user?.id ? "· активный" : ""}
      </button>`).join("")}</div>
    <a class="button" href="#/login">Войти в другой аккаунт</a>
    <a class="button" href="#/profile">Назад</a></section>`;
  for (const item of items) {
    wireButton("switch-" + item.id, async () => {
      user = await api("/accounts/" + item.id + "/switch", {});
      location.hash = "#/profile";
    });
  }
}

function profilePage(data, view) {
  const toolbar = `<div class="profile-tools"><a class="button" href="#/accounts">Аккаунты</a>
    <div class="actions"><a class="button" href="#/profile/search">Поиск по профилю</a>
    <a class="button" href="#/profile/settings">Настройки</a></div></div>`;
  if (view === "settings") {
    main.innerHTML = profileHeader(user, data.images, toolbar) +
      `<section class="panel compact"><h2>Оформление профиля</h2><p class="muted">JPEG, PNG или WebP до 5 МиБ.</p>
      ${["avatar", "cover"].map(kind => form("image-" + kind,
        `<label>${kind === "avatar" ? "Аватар" : "Шапка профиля"}<input type="file" name="image"
        accept="image/jpeg,image/png,image/webp" required></label>`, "Сохранить")).join("")}</section>`;
    for (const kind of ["avatar", "cover"]) {
      wireForm("image-" + kind, async ({ image }) => {
        const response = await fetch("/api/profile/image/" + kind, { method: "POST", body: image });
        if (!response.ok) throw new Error((await response.json()).error || "Не удалось загрузить изображение");
        notify("Изображение обновлено");
        await refresh();
      });
    }
    return;
  }
  if (view === "search") {
    main.innerHTML = profileHeader(user, data.images, toolbar) +
      `<section class="panel"><h2>Поиск по профилю</h2>
      <label>Название или автор<input id="profile-query" type="search" maxlength="120"></label>
      <div id="profile-results"></div></section>`;
    const entries = [...data.history, ...Object.values(data.folders).flat()];
    const unique = [...new Map(entries.map(video => [video.id, video])).values()];
    const input = main.querySelector("#profile-query");
    input.addEventListener("input", () => {
      const needle = input.value.trim().toLocaleLowerCase("ru");
      main.querySelector("#profile-results").innerHTML = needle ? grid(unique.filter(video =>
        [video.title, video.author].some(value => value.toLocaleLowerCase("ru").includes(needle))), "Видео не найдены") : "";
    });
    return;
  }
  main.innerHTML = profileHeader(user, data.images, toolbar) +
    `<div class="actions"><a class="button primary" href="#/studio">Творческая студия</a>
    <a class="button" href="${channel(user.id)}">Мой канал и плейлисты</a></div>
    <section><h2>Просмотренные видео</h2>
    <div class="actions" id="history-filters">
      <button data-kind="all" aria-pressed="true">Все</button><button data-kind="video" aria-pressed="false">Видео</button>
      <button data-kind="short" aria-pressed="false">Shorts</button>
    </div><div id="history-items">${grid(data.history, "История пока пуста")}</div></section>
    <section><h2>Библиотека</h2><div class="library-folders">
    ${Object.entries(folders).map(([key, label]) => `<details><summary>${label} <small>${data.folders[key].length}</small></summary>
    ${grid(data.folders[key], "Здесь пока нет видео")}</details>`).join("")}</div></section>`;
  const filters = main.querySelector("#history-filters");
  filters.addEventListener("click", event => {
    const kind = event.target.dataset.kind;
    if (!kind) return;
    for (const button of filters.querySelectorAll("button")) {
      button.setAttribute("aria-pressed", String(button === event.target));
    }
    const visible = kind === "all" ? data.history : data.history.filter(video => video.is_short === (kind === "short"));
    main.querySelector("#history-items").innerHTML = kind === "short"
      ? shortsGrid(visible, "Просмотренных Shorts пока нет") : grid(visible, "История пока пуста");
  });
}

function studioPage(items, analytics) {
  const stats = new Map(analytics.map(item => [item.id, item]));
  main.innerHTML = `<section><div class="eyebrow">ПРОФИЛЬ / СТУДИЯ</div><h1>Творческая студия</h1>
    <div class="actions"><a class="button primary" href="#/upload">Загрузить видео</a>
    <a class="button" href="#/upload?format=short">Загрузить Shorts</a>
    <a class="button" href="${channel(user.id)}">Плейлисты канала</a>
    <a class="button" href="#/live/start">Начать эфир</a>
    <a class="button" href="#/studio/monetization">Монетизация</a>
    <a class="button" href="#/studio/copyright">Авторские права</a>
    <a class="button" href="#/profile">Назад в профиль</a></div><h2>Ваши публикации</h2>
    ${items.length ? items.map(v => `<details class="panel"><summary>${esc(v.title)} · ${v.is_short ? "Shorts" : "Видео"}
      · ${v.hidden ? "Скрыто модератором" : v.private ? "Приватное" : "Публичное"}</summary>
      <p class="muted">Просмотры: ${stats.get(v.id)?.views || 0} · Зрители: ${stats.get(v.id)?.unique_viewers || 0}
      · Время просмотра: ${videoTime(stats.get(v.id)?.watch_seconds || 0)}</p>
      ${form("cover-" + v.id, '<label>Обложка<input name="cover" type="file" accept="image/jpeg,image/png,image/webp" required></label>', "Загрузить обложку")}
      ${form("edit-" + v.id, `<label>Название<input name="title" required maxlength="120" value="${esc(v.title)}"></label>
      <label>Описание<textarea name="description" maxlength="2000">${esc(v.description)}</textarea></label>
      <label>Доступ<select name="private"><option value="0" ${v.private ? "" : "selected"}>Публичное</option>
      <option value="1" ${v.private ? "selected" : ""}>Приватное</option></select></label>`, "Сохранить",
      v.hidden ? "" : `<a class="button" href="${videoLink(v)}">Открыть видео</a>`)}</details>`).join("")
      : '<div class="empty">У вас пока нет публикаций</div>'}</section>`;
  for (const v of items) {
    wireForm("cover-" + v.id, async ({ cover }) => {
      const response = await fetch("/api/studio/videos/" + v.id + "/cover", {method:"POST",body:cover});
      if (!response.ok) throw new Error((await response.json()).error || "Не удалось загрузить обложку");
      notify("Обложка обновлена");
    });
    wireForm("edit-" + v.id, async data => {
      await api("/studio/videos/" + v.id, { ...data, private: data.private === "1" });
      notify("Публикация обновлена");
      await refresh();
    });
  }
}

function channelPage(c, publicProfile = false) {
  const mine = c.id === user?.id;
  const options = c.videos.map(v => `<option value="${v.id}">${esc(v.title)}</option>`).join("");
  main.innerHTML = (publicProfile || c.images.length ? profileHeader(c, c.images) : "") + `<div class="channel-head">${publicProfile || c.images.length ? "" : `<span class="avatar large">${esc(c.name[0].toUpperCase())}</span>`}
    <div><div class="eyebrow">КАНАЛ</div>${publicProfile || c.images.length ? "" : `<h1>${esc(c.name)}</h1>`}<p class="muted">Подписчики · ${c.followers}</p></div>
    ${mine ? '<a class="button" href="#/upload">Загрузить видео</a>' :
    (user ? `<button id="follow" class="primary" aria-pressed="${c.following}">${c.following ? "Отписаться" : "Подписаться"}</button>` : authLink())}</div>
    <h2>Видео</h2>${grid(c.videos)}<h2>Плейлисты</h2>
    ${mine ? form("playlist", input("title", "Название плейлиста", 100), "Создать плейлист") : ""}
    ${c.playlists.map(p => `<section class="playlist"><h3>${esc(p.title)}</h3>${grid(p.videos)}` +
      (mine && options ? form("playlist-" + p.id, `<label>Видео<select name="video">${options}</select></label>`,
        "Добавить", '<button name="remove">Удалить из плейлиста</button>') : "") + "</section>").join("")}
    ${c.playlists.length ? "" : '<p class="muted">Плейлистов пока нет.</p>'}`;
  if (c.following) {
    const control = document.createElement("button");
    control.type = "button";
    control.id = "channel-notifications";
    control.setAttribute("aria-pressed", String(c.notifications_enabled));
    control.textContent = c.notifications_enabled ? "Уведомления включены" : "Уведомления выключены";
    main.querySelector(".channel-head").append(control);
    wireButton(control.id, async () => {
      await api("/channels/" + c.id + "/notifications", {enabled: !c.notifications_enabled});
      await refresh();
    });
  }
  wireButton("follow", async () => { await api("/channels/" + c.id + "/follow", { enabled: !c.following }); await refresh(); });
  wireForm("playlist", async data => { await api("/playlists", data); await refresh(); });
  c.playlists.forEach(p => wireForm("playlist-" + p.id, async (data, button) => {
    await api("/playlists/" + p.id + "/videos", { ...data, enabled: button?.name !== "remove" });
    await refresh();
  }));
}

function moderationPage(reports) {
  main.innerHTML = `<div class="eyebrow">УПРАВЛЕНИЕ</div><h1>Модерация</h1><p><a class="button" href="#/moderation/copyright">Совпадения по авторским правам</a></p>` +
    (reports.length ? reports.map(r => `<article class="panel report"><small>Жалоба №${r.id} · ${r.resolved ? "Рассмотрена" : "Ожидает решения"}</small>
      <h2>${esc(r.title)}</h2><p>${esc(r.reason)}</p><div class="actions">
      ${r.hidden ? "" : `<a class="button" href="${watch(r.video)}">Открыть видео</a>`}
      <button class="primary" id="moderate-${r.id}">${r.hidden ? "Восстановить" : "Скрыть видео"}</button>
      ${r.resolved ? "" : `<button id="dismiss-${r.id}">Отклонить жалобу</button>`}</div></article>`).join("") :
      '<div class="empty">Жалоб пока нет</div>');
  reports.forEach(r => {
    const act = async action => { await api("/moderation/" + r.id, { action }); await refresh(); };
    wireButton("moderate-" + r.id, () => act(r.hidden ? "restore" : "hide"));
    wireButton("dismiss-" + r.id, () => act("dismiss"));
  });
}

function usersPage(users) {
  const roles = { user: "Пользователь", moderator: "Модератор", admin: "Администратор" };
  main.innerHTML = '<div class="eyebrow">АДМИНИСТРИРОВАНИЕ</div><h1>Роли пользователей</h1>' + users.map(u =>
    `<section class="panel"><h2>${esc(u.name)}</h2>` +
    (u.id === user.id ? `<p>${roles[u.role]} · ваш аккаунт</p>` :
      form("role-" + u.id, '<label>Роль<select name="role">' + Object.entries(roles).map(([value, label]) =>
        `<option value="${value}" ${value === u.role ? "selected" : ""}>${label}</option>`).join("") + '</select></label>', "Сохранить")) +
    '</section>').join("");
  users.forEach(u => wireForm("role-" + u.id, async data => {
    await api("/users/" + u.id + "/role", data);
    notify("Роль сохранена");
    await refresh();
  }));
}

function monetizationPage(data) {
  main.innerHTML = `<a class="accent" href="#/studio">← Творческая студия</a><h1>Монетизация</h1>
    <p class="muted">Демонстрационные баллы. Они не имеют денежной стоимости.</p>
    <div class="studio-metrics">
      <div class="panel">Баланс<strong>${data.balance}</strong></div>
      <div class="panel">Получено<strong>${data.received}</strong></div>
      <div class="panel">Отправлено<strong>${data.sent}</strong></div>
    </div><button id="monetization-toggle" aria-pressed="${data.enabled}">${data.enabled ? "Отключить поддержку" : "Принимать поддержку"}</button>
    <h2>Операции</h2>${data.activity.length ? data.activity.map(item =>
      `<p class="panel">${item.incoming ? "+" : "−"}${item.amount} · ${esc(item.title)}</p>`).join("") : '<div class="empty">Операций пока нет</div>'}`;
  wireButton("monetization-toggle", async () => {
    await api("/studio/monetization", {enabled: !data.enabled});
    await refresh();
  });
}

const copyrightStatus = {pending:"Ожидает проверки",confirmed:"Совпадение подтверждено",dismissed:"Отклонено"};

function copyrightPage(data) {
  main.innerHTML = `<a class="accent" href="#/studio">← Творческая студия</a><h1>Авторские права</h1>
    <p class="muted">Регистрируйте только материалы, на которые у вас есть права. Совпадение проверяет модератор.</p>
    <h2>Совпадения ваших загрузок</h2>${data.matches.length ? data.matches.map(match =>
      `<p class="panel">${esc(match.title)} · ${copyrightStatus[match.status]}</p>`).join("") : '<div class="empty">Совпадений пока нет</div>'}
    <h2>Эталонные видео</h2>${data.references.length ? data.references.map(item =>
      `<div class="panel watchbar"><strong>${esc(item.title)}</strong>
       <button id="ref-${item.id}" aria-pressed="${item.active}">${item.active ? "Снять с проверки" : "Зарегистрировать эталон"}</button></div>`).join("")
      : '<div class="empty">Сначала загрузите видео.</div>'}`;
  for (const item of data.references) wireButton("ref-" + item.id, async () => {
    await api("/studio/copyright/" + item.id, {enabled: !item.active});
    await refresh();
  });
}

function copyrightModerationPage(items) {
  main.innerHTML = `<a class="accent" href="#/moderation">← Модерация</a><h1>Совпадения по авторским правам</h1>
    ${items.length ? items.map(item => `<div class="panel"><h2>${esc(item.title)}</h2>
    <p>Эталон: ${esc(item.reference)} · ${copyrightStatus[item.status]}</p>
    ${item.video_visible ? `<a class="button" href="${watch(item.video)}">Открыть видео</a>` : ""}
    ${item.reference_visible ? `<a class="button" href="${watch(item.reference_id)}">Открыть эталон</a>` : ""}
    ${item.status === "pending" ? `<div class="actions"><button id="confirm-${item.id}">Подтвердить совпадение</button>
    <button id="dismiss-match-${item.id}">Отклонить</button></div>` : ""}</div>`).join("")
    : '<div class="empty">Очередь пуста</div>'}`;
  for (const item of items) {
    for (const [prefix,status] of [["confirm-","confirmed"],["dismiss-match-","dismissed"]]) {
      wireButton(prefix + item.id, async () => {
        await api("/moderation/copyright/" + item.id, {status});
        await refresh();
      });
    }
  }
}

function liveList(rooms) {
  main.innerHTML = `<div class="watchbar"><h1>Прямые эфиры</h1>
    ${user ? '<a class="button primary" href="#/live/start">Начать эфир</a>' : authLink()}</div>
    <p class="muted">Трансляции авторов в реальном времени.</p>
    ${rooms.length ? `<div class="grid">${rooms.map(room =>
      `<a class="panel live-card" href="#/live/${room.id}"><span class="on-air">В ЭФИРЕ</span>
      <h2>${esc(room.title)}</h2><small>${esc(room.author)} · зрителей: ${room.viewers}</small></a>`).join("")}</div>`
      : '<div class="empty">Активных эфиров пока нет</div>'}`;
}

function liveConnection(path, video, status, stream = null) {
  const socket = new WebSocket(new URL("/api/live/" + path, location.origin.replace(/^http/, "ws")));
  const peers = new Map();
  let stopped = false;
  const send = data => { if (socket.readyState === WebSocket.OPEN) socket.send(JSON.stringify(data)); };
  function finish(message) {
    if (stopped) return;
    stopped = true;
    if (stream) stream.getTracks().forEach(track => track.stop());
    peers.forEach(peer => peer.pc.close());
    peers.clear();
    video.srcObject = null;
    socket.close();
    if (message) status.textContent = message;
  }
  function makePeer(id) {
    const pc = new RTCPeerConnection();
    const peer = {pc, ice: []};
    peers.set(id, peer);
    pc.onicecandidate = event => {
      if (event.candidate) send({type:"ice",peer:id,data:event.candidate.toJSON()});
    };
    pc.onconnectionstatechange = () => {
      if (!stream && pc.connectionState === "connected") status.textContent = "В эфире";
      if (pc.connectionState === "failed") {
        if (stream) { pc.close(); peers.delete(id); }
        else finish("Соединение с автором не установлено.");
      }
    };
    pc.ontrack = event => {
      video.srcObject = event.streams[0];
      video.play().catch(() => { status.textContent = "Нажмите ▶, чтобы смотреть эфир."; });
    };
    if (stream) stream.getTracks().forEach(track => pc.addTrack(track, stream));
    return peer;
  }
  let tasks = Promise.resolve();
  socket.onmessage = event => {
    tasks = tasks.then(async () => {
      if (stopped) return;
      const msg = JSON.parse(event.data);
      if (msg.type === "ready") {
        status.textContent = "В эфире";
        const share = document.querySelector("#live-share");
        share.href = "#/live/" + msg.room;
        share.hidden = false;
        return;
      }
      if (msg.type === "error" || msg.type === "ended") {
        finish(msg.message || "Эфир завершён.");
        return;
      }
      if (msg.type === "leave") {
        peers.get(msg.peer)?.pc.close();
        peers.delete(msg.peer);
        return;
      }
      const id = stream ? msg.peer : "host";
      if (stream && !["join","answer","ice"].includes(msg.type)) return;
      const peer = peers.get(id) || makePeer(id);
      if (msg.type === "join") {
        await peer.pc.setLocalDescription(await peer.pc.createOffer());
        send({type:"offer",peer:id,data:peer.pc.localDescription.toJSON()});
      } else if (msg.type === "offer" || msg.type === "answer") {
        await peer.pc.setRemoteDescription(msg.data);
        for (const candidate of peer.ice.splice(0)) await peer.pc.addIceCandidate(candidate);
        if (msg.type === "offer") {
          await peer.pc.setLocalDescription(await peer.pc.createAnswer());
          send({type:"answer",data:peer.pc.localDescription.toJSON()});
        }
      } else if (msg.type === "ice") {
        if (peer.pc.remoteDescription) await peer.pc.addIceCandidate(msg.data);
        else peer.ice.push(msg.data);
      }
    }).catch(() => {
      if (!stream) finish("Не удалось установить соединение.");
    });
  };
  socket.onclose = () => finish("Соединение закрыто.");
  socket.onerror = () => finish("Не удалось подключиться к эфиру.");
  return () => { if (stream) send({type:"end"}); finish("Эфир завершён."); };
}

function livePage(room, start) {
  if (!user) {
    main.innerHTML = '<section class="panel compact"><h1>Прямые эфиры</h1><p>Войдите, чтобы начать или посмотреть эфир.</p>' + authLink() + '</section>';
    return;
  }
  main.innerHTML = `<section class="watch"><a class="accent" href="#/live">← Все эфиры</a>
    <h1>${start ? "Начать эфир" : esc(room.title)}</h1>
    ${start ? form("start-live", input("title", "Название эфира", 120), "Включить камеру и выйти в эфир") : `<p class="muted">${esc(room.author)}</p>`}
    <video id="live-video" ${start ? "muted" : "controls"} autoplay playsinline ${start ? "hidden" : ""}></video>
    <p id="live-status" role="status">${start ? "Нужен доступ к камере и микрофону." : "Подключение к эфиру…"}</p>
    ${start ? '<div class="actions"><a id="live-share" class="button" target="_blank" rel="noopener" hidden>Открыть ссылку для зрителя</a><button id="end-live" hidden>Завершить эфир</button></div>' : ""}</section>`;
  const video = main.querySelector("#live-video");
  const status = main.querySelector("#live-status");
  if (!start) {
    closeLive = liveConnection("watch/" + room.id, video, status);
    return;
  }
  wireForm("start-live", async ({title}, button, target) => {
    if (!navigator.mediaDevices?.getUserMedia) throw new Error("Камера доступна на localhost или по HTTPS.");
    const media = await navigator.mediaDevices.getUserMedia({video:true,audio:true});
    if (!target.isConnected) {
      media.getTracks().forEach(track => track.stop());
      return;
    }
    video.hidden = false;
    video.srcObject = media;
    target.hidden = true;
    const end = main.querySelector("#end-live");
    end.hidden = false;
    status.textContent = "Запуск эфира…";
    closeLive = liveConnection("host?" + new URLSearchParams({title}), video, status, media);
  });
  wireButton("end-live", () => {
    closeLive?.();
    closeLive = null;
    location.hash = "#/live";
  });
}

async function render(preserve = false) {
  const turn = ++revision;
  flushPlayback?.();
  flushPlayback = null;
  closeLive?.();
  closeLive = null;
  const [path, query = ""] = (location.hash.slice(1) || "/").split("?");
  const [, page, id] = path.split("/");
  const q = new URLSearchParams(query).get("q") || "";
  const oldVideo = preserve && main.querySelector("video");
  const playback = oldVideo ? { time: oldVideo.currentTime, playing: !oldVideo.paused, muted: oldVideo.muted } : null;
  chrome(path);
  search.elements.q.value = page === "search" ? q : "";
  if (!preserve) {
    window.scrollTo(0, 0);
    main.innerHTML = '<p class="muted" role="status">Загрузка…</p>';
  }
  try {
    if (page === "search") {
      const params = new URLSearchParams(query);
      const [items, channels] = await Promise.all([api("/videos?" + params),
        api("/channels?" + new URLSearchParams({q}))]);
      if (turn === revision) searchPage(items, channels, params);
    } else if (!page) {
      const items = await api("/videos?" + new URLSearchParams({ q }));
      if (turn !== revision) return;
      main.innerHTML = `<section class="hero"><div><div class="eyebrow">K I N O F L O W &nbsp; / &nbsp; В И Д Е О</div>
          <h1>Смотрите.<br>Делитесь своим.</h1><p>Видео, каналы и подборки авторов.</p></div>
          <a class="button" href="#/upload">↑ Загрузить видео</a></section>
          <h2>Свежие видео</h2>${grid(items.filter(v => !v.is_short), "Лента пока пуста. Загрузите первое видео.")}
          ${items.some(v => v.is_short) ? `<div class="shorts-heading"><h2>Shorts</h2><a class="accent" href="#/shorts">Все Shorts →</a></div>${shortsGrid(items.filter(v => v.is_short).slice(0, 4))}` : ""}`;
    } else if (page === "shorts" && !id) {
      const items = await api("/shorts");
      if (turn === revision) shortsPage(items);
    } else if (page === "shorts" && /^[a-f0-9]{32}$/.test(id)) {
      const [data, items] = await Promise.all([api("/videos/" + id), api("/shorts")]);
      if (turn !== revision) return;
      if (!data.is_short || !items.some(item => item.id === id)) throw new Error("Короткий ролик недоступен");
      watchPage(data, playback, items);
    } else if (page === "watch" && /^[a-f0-9]{32}$/.test(id)) {
      const data = await api("/videos/" + id);
      if (turn === revision) watchPage(data, playback);
    } else if (page === "live") {
      if (id === "start") livePage(null, true);
      else {
        const rooms = await api("/live");
        if (turn !== revision) return;
        if (!id) liveList(rooms);
        else {
          const room = rooms.find(item => item.id === id);
          if (!room) throw new Error("Эфир завершён или недоступен.");
          livePage(room, false);
        }
      }
    } else if (page === "recommendations") {
      const items = await api("/recommendations");
      if (turn !== revision) return;
      main.innerHTML = `<div class="eyebrow">ПОДБОРКА ВИДЕО</div><h1>Рекомендации</h1>
        <p class="muted">${user ? "Подборка учитывает просмотры, лайки и подписки." : "Свежие ролики. Войдите, чтобы получать подборку по своим интересам."}</p>
        ${grid(items, "Подходящих роликов пока нет")}`;
    } else if (page === "subscriptions") {
      if (!user) {
        main.innerHTML = '<section class="panel compact"><h1>Подписки</h1><p>Войдите, чтобы увидеть публикации ваших каналов.</p>' + authLink() + '</section>';
        return;
      }
      const data = await api("/subscriptions");
      if (turn === revision) subscriptionsPage(data);
    } else if (page === "notifications") {
      if (!user) {
        main.innerHTML = '<section class="panel compact"><h1>Уведомления</h1><p>Войдите, чтобы увидеть уведомления.</p>' + authLink() + '</section>';
        return;
      }
      const data = await api("/notifications");
      if (turn === revision) notificationsPage(data);
    } else if (page === "accounts") {
      const items = await api("/accounts");
      if (turn === revision) accountsPage(items);
    } else if (page === "profile" || page === "studio") {
      if (!user) {
        main.innerHTML = `<section class="panel compact"><h1>Профиль</h1>
          <p>Войдите, чтобы открыть историю, библиотеку и студию.</p>
          <div class="actions">${authLink()}<a class="button" href="#/register">Создать аккаунт</a>
          <a class="button" href="#/accounts">Аккаунты</a></div></section>`;
        return;
      }
      if (page === "profile") {
        const data = await api("/profile");
        if (turn === revision) profilePage(data, id);
      } else if (id === "monetization" || id === "copyright") {
        const data = await api("/studio/" + id);
        if (turn !== revision) return;
        if (id === "monetization") monetizationPage(data);
        else copyrightPage(data);
      } else {
        const [items, analytics] = await Promise.all([api("/studio"),api("/studio/analytics")]);
        if (turn === revision) studioPage(items, analytics);
      }
    } else if (page === "u" && id) {
      const data = await api("/u/" + encodeURIComponent(decodeURIComponent(id)));
      if (turn === revision) channelPage(data, true);
    } else if (page === "channel" && /^\d{1,12}$/.test(id)) {
      const data = await api("/channels/" + id);
      if (turn === revision) channelPage(data);
    } else if (page === "moderation") {
      const data = await api(id === "copyright" ? "/moderation/copyright" : "/moderation");
      if (turn !== revision) return;
      if (id === "copyright") copyrightModerationPage(data);
      else moderationPage(data);
    } else if (page === "users") {
      const data = await api("/users");
      if (turn === revision) usersPage(data);
    } else if (page === "upload") uploadPage(new URLSearchParams(query).get("format") === "short");
    else if (page === "login" || page === "register") authPage(page === "register");
    else throw new Error("Страница не найдена");
  } catch (error) {
    if (turn === revision) main.innerHTML = `<div class="empty">${esc(error.message)}<br><a class="accent" href="#/">На главную</a></div>`;
  }
}

search.addEventListener("submit", event => {
  event.preventDefault();
  location.hash = "#/search?" + new URLSearchParams({ q: search.elements.q.value.trim() });
});
window.addEventListener("hashchange", () => render());
api("/me").then(data => { user = data; }).catch(error => notify(error.message)).finally(() => render());
