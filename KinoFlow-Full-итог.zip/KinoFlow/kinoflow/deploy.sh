#!/usr/bin/env bash
set -Eeuo pipefail

if [[ $EUID -ne 0 ]]; then
    exec sudo bash "$0" "$@"
fi

source /etc/os-release
if [[ ${ID:-} != ubuntu || ${VERSION_ID:-} != 24.04 ]]; then
    echo "Этот скрипт рассчитан на Ubuntu 24.04 LTS." >&2
    exit 1
fi
if [[ ! -d /run/systemd/system ]]; then
    echo "Требуется Ubuntu с запущенным systemd." >&2
    exit 1
fi

source_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
app_dir=/opt/kinoflow
data_dir=/var/lib/kinoflow
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y --no-install-recommends \
    postgresql python3-fastapi python3-uvicorn python3-websockets python3-psycopg2 python3-pil ffmpeg curl

if ! id kinoflow >/dev/null 2>&1; then
    useradd --system --user-group --home-dir "$data_dir" --shell /usr/sbin/nologin kinoflow
fi
systemctl enable --now postgresql.service
runuser -u postgres -- psql -X -v ON_ERROR_STOP=1 -d postgres <<'SQL'
SELECT 'CREATE ROLE kinoflow LOGIN'
WHERE NOT EXISTS (SELECT FROM pg_roles WHERE rolname='kinoflow') \gexec
SELECT 'CREATE DATABASE kinoflow OWNER kinoflow'
WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname='kinoflow') \gexec
SQL

install -d -m 0755 "$app_dir" "$app_dir/web"
install -d -m 0750 -o kinoflow -g kinoflow "$data_dir"
if [[ "$source_dir" != "$app_dir" ]]; then
    install -m 0644 "$source_dir"/{server.py,worker.py,live.py,media.py,demo.py,schema.sql,README.md,PROMPTS.md} "$app_dir/"
    install -m 0644 "$source_dir"/web/{index.html,app.js,style.css} "$app_dir/web/"
fi

cat > /etc/systemd/system/kinoflow.service <<'UNIT'
[Unit]
Description=KinoFlow video platform
After=postgresql.service
Requires=postgresql.service

[Service]
Type=simple
User=kinoflow
Group=kinoflow
WorkingDirectory=/opt/kinoflow
Environment=DATABASE_URL=dbname=kinoflow
Environment=KINOFLOW_DATA=/var/lib/kinoflow
Environment=HOST=127.0.0.1
Environment=PORT=8000
ExecStart=/usr/bin/python3 /opt/kinoflow/server.py
Restart=on-failure
RestartSec=3
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=/var/lib/kinoflow
UMask=0077

[Install]
WantedBy=multi-user.target
UNIT

cat > /etc/systemd/system/kinoflow-worker.service <<'UNIT'
[Unit]
Description=KinoFlow video processing worker
After=kinoflow.service postgresql.service
Requires=postgresql.service
PartOf=kinoflow.service

[Service]
Type=simple
User=kinoflow
Group=kinoflow
WorkingDirectory=/opt/kinoflow
Environment=DATABASE_URL=dbname=kinoflow
Environment=KINOFLOW_DATA=/var/lib/kinoflow
ExecStart=/usr/bin/python3 /opt/kinoflow/worker.py
Restart=on-failure
RestartSec=3
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=/var/lib/kinoflow
UMask=0077

[Install]
WantedBy=multi-user.target
UNIT

systemctl daemon-reload
systemctl enable kinoflow.service kinoflow-worker.service
systemctl restart kinoflow.service kinoflow-worker.service
for ((attempt=1; attempt<=30; attempt++)); do
    if systemctl is-active --quiet kinoflow-worker.service &&
       curl --noproxy '*' -fsS --max-time 2 http://127.0.0.1:8000/api/health >/dev/null 2>&1 &&
       curl --noproxy '*' -fsS --max-time 2 http://127.0.0.1:8000/openapi.json >/dev/null 2>&1; then
        printf '%s\n' 'KinoFlow: http://127.0.0.1:8000' 'Swagger:  http://127.0.0.1:8000/docs'
        exit 0
    fi
    sleep 1
done
journalctl -u kinoflow.service -u kinoflow-worker.service -n 35 --no-pager >&2
exit 1
