import json
import subprocess
from decimal import Decimal
from pathlib import Path


class InvalidShort(ValueError):
    pass


def video_info(video: Path):
    probe = subprocess.check_output([
        "ffprobe", "-v", "error", "-select_streams", "v:0",
        "-show_entries", "stream=width,height:format=duration", "-of", "json", str(video),
    ], timeout=15, stderr=subprocess.DEVNULL)
    info = json.loads(probe)
    streams = info.get("streams", [])
    duration = Decimal(info.get("format", {}).get("duration", "0"))
    if not streams or not duration.is_finite() or duration <= 0:
        raise ValueError("Не удалось определить длительность видео")
    return float(duration), streams[0]["height"] > streams[0]["width"]


def transcode(raw: Path, is_short: bool):
    folder = raw.parent
    ffmpeg = ["ffmpeg", "-y", "-nostdin", "-hide_banner", "-loglevel", "error", "-threads", "2",
              "-protocol_whitelist", "file", "-format_whitelist", "mov,matroska,avi,mpegts,mpeg,flv,ogg", "-i", str(raw)]
    output = folder / "video.mp4"
    limit = ["-t", "61"] if is_short else []
    subprocess.run(ffmpeg + limit + [
        "-map", "0:v:0", "-map", "0:a:0?", "-vf",
        "scale=1280:720:force_original_aspect_ratio=decrease:force_divisible_by=2,setsar=1",
        "-c:v", "libx264", "-threads", "2", "-preset", "veryfast", "-pix_fmt", "yuv420p",
        "-c:a", "aac", "-movflags", "+faststart", str(output),
    ], check=True, timeout=180, stderr=subprocess.DEVNULL)
    duration, portrait = video_info(output)
    if is_short and not portrait:
        raise InvalidShort("Для Shorts загрузите вертикальное видео.")
    if is_short and duration > 60:
        raise InvalidShort("Продолжительность Shorts — не более 60 секунд.")
    subprocess.run(["ffmpeg", "-y", "-nostdin", "-loglevel", "error", "-i", str(output),
                    "-frames:v", "1", "-update", "1", str(folder / "poster.jpg")],
                   check=True, timeout=30, stderr=subprocess.DEVNULL)
    if not (folder / "poster.jpg").is_file():
        raise ValueError("В файле нет видеокадров")
    return duration
