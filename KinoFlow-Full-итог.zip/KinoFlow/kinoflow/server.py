import hashlib
import os
import re
import secrets
import shutil
import subprocess
import sys
import time
from contextlib import asynccontextmanager
from io import BytesIO
from pathlib import Path
from typing import Literal
from uuid import UUID

import psycopg2
from PIL import Image, ImageOps, UnidentifiedImageError
from psycopg2.extras import RealDictCursor
from fastapi import APIRouter, Depends, FastAPI, HTTPException, Query, Request, Response, Security
from fastapi.exceptions import RequestValidationError
from fastapi.responses import FileResponse, JSONResponse, StreamingResponse
from fastapi.security import APIKeyCookie
from pydantic import BaseModel, Field
from starlette.concurrency import run_in_threadpool

from live import router as live_router
from media import video_info

ROOT = Path(__file__).resolve().parent
MEDIA = Path(os.environ.get("KINOFLOW_DATA", ROOT / "data")) / "media"
DSN = os.environ.get("DATABASE_URL", "dbname=kinoflow")
MAX_VIDEO = 100 * 1024 * 1024
SESSION_AGE = 604800
Role = Literal["user", "moderator", "admin"]
STAFF = ("moderator", "admin")
COOKIE = APIKeyCookie(name="session", auto_error=False)
ACCOUNT_COOKIE = "kf_account_"
COOKIE_OPTIONS = {"httponly": True, "samesite": "strict", "secure": os.environ.get("COOKIE_SECURE") == "1"}
MAX_PROFILE_IMAGE = 5 * 1024 * 1024
ImageKind = Literal["avatar", "cover"]


class Credentials(BaseModel):
    name: str = Field(min_length=1, max_length=32)
    password: str = Field(min_length=1, max_length=128)


class Account(BaseModel):
    id: int
    name: str
    role: Role


class VideoCard(BaseModel):
    id: str
    owner: int
    author: str
    title: str
    description: str
    private: int
    hidden: int
    created: int
    is_short: bool
    duration_seconds: float | None = None


class CommentView(BaseModel):
    id: int
    name: str
    body: str


class VideoDetails(VideoCard):
    comments: list[CommentView]
    likes: int
    liked: bool
    grants: list[str] | None = None
    folders: list[str] | None = None
    position_seconds: float = 0
    support_enabled: bool = False


class PlaylistView(BaseModel):
    id: int
    title: str
    videos: list[VideoCard]


class ChannelView(BaseModel):
    images: list[ImageKind]
    notifications_enabled: bool = False
    id: int
    name: str
    videos: list[VideoCard]
    playlists: list[PlaylistView]
    followers: int
    following: bool


class ReportView(BaseModel):
    id: int
    video: str
    title: str
    reason: str
    resolved: int
    hidden: int


class UploadResult(BaseModel):
    id: str
    status: Literal["processing", "ready", "failed"] = "processing"
    error: str | None = None
    copyright_matches: int = 0


class Toggle(BaseModel):
    enabled: bool


class Grant(Toggle):
    name: str = Field(min_length=1, max_length=32)


class Comment(BaseModel):
    body: str = Field(min_length=1, max_length=1000)


class Report(BaseModel):
    reason: str = Field(min_length=1, max_length=500)


class Playlist(BaseModel):
    title: str = Field(min_length=1, max_length=100)


class PlaylistVideo(Toggle):
    video: str = Field(min_length=32, max_length=32)


class Decision(BaseModel):
    action: Literal["hide", "restore", "dismiss"]


class RoleChange(BaseModel):
    role: Role


def connect():
    return psycopg2.connect(DSN, cursor_factory=RealDictCursor, connect_timeout=5)


def clean(text):
    if not (value := text.strip()) or "\0" in value:
        raise HTTPException(400, "Заполните поле корректным текстом")
    return value


def password_hash(password, salt=None):
    salt = salt or secrets.token_hex(16)
    digest = hashlib.scrypt(password.encode(), salt=bytes.fromhex(salt), n=16384, r=8, p=1)
    return salt + ":" + digest.hex()


def query(cursor, sql, params=(), many=False):
    cursor.execute(sql, params)
    return cursor.fetchall() if many else cursor.fetchone()


def init_schema():
    conn = connect()
    try:
        with conn, conn.cursor() as cursor:
            cursor.execute("SELECT pg_advisory_xact_lock(741628)")
            cursor.execute((ROOT / "schema.sql").read_text(encoding="utf-8"))
        with conn, conn.cursor() as cursor:
            for row in query(cursor, "SELECT id FROM videos WHERE duration_seconds IS NULL", many=True):
                try:
                    duration, _ = video_info(MEDIA / row["id"] / "video.mp4")
                except (OSError, ValueError, ArithmeticError, subprocess.SubprocessError):
                    continue
                cursor.execute("UPDATE videos SET duration_seconds=%s WHERE id=%s", (duration, row["id"]))
    finally:
        conn.close()


@asynccontextmanager
async def lifespan(app):
    MEDIA.mkdir(parents=True, exist_ok=True)
    await run_in_threadpool(init_schema)
    yield


app = FastAPI(title="KinoFlow API", version="2.0", lifespan=lifespan)
api = APIRouter(prefix="/api")


@app.exception_handler(HTTPException)
async def http_error(request, error):
    return JSONResponse({"error": error.detail}, error.status_code, headers=error.headers)


@app.exception_handler(RequestValidationError)
async def validation_error(request, error):
    location = ", ".join(".".join(map(str, item["loc"])) for item in error.errors())
    return JSONResponse({"error": f"Проверьте поля запроса: {location}"}, 422)


@app.middleware("http")
async def request_policy(request, call_next):
    origin = request.headers.get("origin")
    if request.method == "POST" and origin and origin != str(request.base_url).rstrip("/"):
        return JSONResponse({"error": "Запрос с другого сайта отклонён"}, 403)
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Referrer-Policy"] = "no-referrer"
    if request.url.path.startswith("/api/"):
        response.headers["Cache-Control"] = "private, no-store"
    if request.url.path in {"/", "/app.js", "/style.css"}:
        response.headers["Content-Security-Policy"] = "default-src 'self'; object-src 'none'; frame-ancestors 'none'; base-uri 'none'"
    return response


class Context:
    def __init__(self, cursor, token):
        self.cursor = cursor
        self.user = query(cursor, """
            SELECT u.id,u.name,u.role FROM users u JOIN sessions s ON u.id=s.user_id
            WHERE s.token=%s AND s.expires>%s
        """, (token, int(time.time()))) if token else None
        self.uid = self.user["id"] if self.user else None

    def require(self, roles=None):
        if not self.user:
            raise HTTPException(401, "Войдите в аккаунт")
        if roles and self.user["role"] not in roles:
            raise HTTPException(403, "Недостаточно прав")

    def videos(self, where="TRUE", args=(), order="v.created DESC,v.id"):
        return query(self.cursor, """
            SELECT v.*, u.name AS author FROM videos v JOIN users u ON u.id=v.owner
            WHERE v.hidden=0 AND (v.private=0 OR v.owner=%s OR EXISTS (
                SELECT 1 FROM grants g WHERE g.video=v.id AND g.user_id=%s
            )) AND """ + where + " ORDER BY " + order, (self.uid, self.uid, *args), many=True)

    def video(self, video_id, lock=False):
        if not re.fullmatch(r"[a-f0-9]{32}", video_id):
            raise HTTPException(404, "Видео недоступно")
        if lock:
            self.cursor.execute("SELECT id FROM videos WHERE id=%s FOR UPDATE", (video_id,))
        rows = self.videos("v.id=%s", (video_id,))
        if not rows:
            raise HTTPException(404, "Видео недоступно")
        return rows[0]

    def commit(self):
        self.cursor.connection.commit()


def context(token=Security(COOKIE)):
    conn = connect()
    try:
        with conn.cursor() as cursor:
            yield Context(cursor, token)
    finally:
        conn.close()


Db = Depends(context)


def browser_accounts(request, ctx):
    tokens = [value for key, value in request.cookies.items()
              if key == "session" or key.startswith(ACCOUNT_COOKIE)]
    return query(ctx.cursor, """
        SELECT DISTINCT ON (u.id) u.id,u.name,u.role,s.token,s.expires
        FROM users u JOIN sessions s ON u.id=s.user_id
        WHERE s.token=ANY(%s) AND s.expires>%s
        ORDER BY u.id, s.expires DESC
    """, (tokens, int(time.time())), many=True)


def create_session(ctx, data, request, response, register=False):
    name = clean(data.name)
    if "\0" in data.password:
        raise HTTPException(400, "Некорректный пароль")
    if register:
        if len(data.password) < 8 or not re.fullmatch(r"[\w.-]{3,32}", name):
            raise HTTPException(400, "Имя от 3 до 32 символов, пароль от 8 символов")
        row = query(ctx.cursor, """
            INSERT INTO users(name,password) VALUES(%s,%s)
            ON CONFLICT(name) DO NOTHING RETURNING id,name,role
        """, (name, password_hash(data.password)))
        if not row:
            raise HTTPException(409, "Имя уже занято")
    else:
        row = query(ctx.cursor, "SELECT * FROM users WHERE name=%s", (name,))
        saved = row["password"] if row else "0"*32 + ":" + "0"*128
        if not secrets.compare_digest(password_hash(data.password, saved.split(":")[0]), saved):
            raise HTTPException(401, "Неверное имя или пароль")
    existing = browser_accounts(request, ctx)
    if len(existing) >= 8 and all(account["id"] != row["id"] for account in existing):
        raise HTTPException(409, "В браузере уже подключены восемь аккаунтов")
    if ctx.uid and ctx.uid != row["id"] and ACCOUNT_COOKIE + str(ctx.uid) not in request.cookies:
        response.set_cookie(ACCOUNT_COOKIE + str(ctx.uid), request.cookies["session"],
                            max_age=SESSION_AGE, **COOKIE_OPTIONS)
    old_token = request.cookies.get(ACCOUNT_COOKIE + str(row["id"]))
    if old_token:
        ctx.cursor.execute("DELETE FROM sessions WHERE token=%s AND user_id=%s", (old_token, row["id"]))
    token = secrets.token_urlsafe(32)
    now = int(time.time())
    ctx.cursor.execute("DELETE FROM sessions WHERE expires<=%s", (now,))
    ctx.cursor.execute("INSERT INTO sessions VALUES(%s,%s,%s)", (token, row["id"], now + SESSION_AGE))
    ctx.commit()
    response.set_cookie("session", token, max_age=SESSION_AGE, **COOKIE_OPTIONS)
    response.set_cookie(ACCOUNT_COOKIE + str(row["id"]), token, max_age=SESSION_AGE, **COOKIE_OPTIONS)
    return {key: row[key] for key in ("id", "name", "role")}


@api.post("/register", tags=["Аккаунты"], response_model=Account)
def register(data: Credentials, request: Request, response: Response, ctx: Context = Db):
    return create_session(ctx, data, request, response, register=True)


@api.post("/login", tags=["Аккаунты"], response_model=Account)
def login(data: Credentials, request: Request, response: Response, ctx: Context = Db):
    return create_session(ctx, data, request, response)


@api.post("/logout", tags=["Аккаунты"])
def logout(request: Request, response: Response, ctx: Context = Db):
    ctx.cursor.execute("DELETE FROM sessions WHERE token=%s", (request.cookies.get("session"),))
    ctx.commit()
    response.delete_cookie("session", **COOKIE_OPTIONS)
    if ctx.uid:
        response.delete_cookie(ACCOUNT_COOKIE + str(ctx.uid), **COOKIE_OPTIONS)
    return {}


@api.get("/accounts", tags=["Аккаунты"], response_model=list[Account])
def accounts(request: Request, ctx: Context = Db):
    return browser_accounts(request, ctx)


@api.post("/accounts/{user_id}/switch", tags=["Аккаунты"], response_model=Account)
def switch_account(user_id: int, request: Request, response: Response, ctx: Context = Db):
    row = next((account for account in browser_accounts(request, ctx) if account["id"] == user_id), None)
    if not row:
        raise HTTPException(403, "Сначала войдите в этот аккаунт")
    response.set_cookie("session", row["token"], max_age=max(1, row["expires"] - int(time.time())), **COOKIE_OPTIONS)
    return row


@api.get("/me", tags=["Аккаунты"], response_model=Account | None)
def me(ctx: Context = Db):
    return ctx.user


@api.get("/videos", tags=["Видео"], response_model=list[VideoCard])
def videos(q: str = Query("", max_length=120),
           format: Literal["all", "video", "short"] = "all",
           days: Literal["all", "1", "7", "30"] = "all",
           length: Literal["all", "under4", "4to20", "over20"] = "all",
           ctx: Context = Db):
    clauses, args = [], []
    if format != "all":
        clauses.append("v.is_short=%s")
        args.append(format == "short")
    if days != "all":
        clauses.append("v.published_at >= now() - %s * interval '1 day'")
        args.append(int(days))
    if length != "all":
        clauses.append({"under4": "v.duration_seconds<240",
                        "4to20": "v.duration_seconds BETWEEN 240 AND 1200",
                        "over20": "v.duration_seconds>1200"}[length])
    items = ctx.videos(" AND ".join(clauses) or "TRUE", tuple(args))
    needle = q.strip().casefold()
    return [video for video in items if any(needle in video[field].casefold()
            for field in ("title", "description", "author"))] if needle else items


class ChannelMatch(BaseModel):
    id: int
    name: str


@api.get("/channels", tags=["Каналы"], response_model=list[ChannelMatch])
def find_channels(q: str = Query("", max_length=120), ctx: Context = Db):
    needle = q.strip().casefold()
    if not needle:
        return []
    return [row for row in query(ctx.cursor, "SELECT id,name FROM users ORDER BY name,id", many=True)
            if needle in row["name"].casefold()][:30]


class SubscriptionChannel(BaseModel):
    id: int
    name: str
    has_avatar: bool
    new_count: int


class SubscriptionsView(BaseModel):
    channels: list[SubscriptionChannel]
    videos: list[VideoCard]
    new_ids: list[str]


@api.get("/subscriptions", tags=["Каналы"], response_model=SubscriptionsView)
def subscriptions(ctx: Context = Db):
    ctx.require()
    channels = query(ctx.cursor, """
        SELECT u.id,u.name,f.followed_at, EXISTS (
            SELECT 1 FROM profile_images p WHERE p.user_id=u.id AND p.kind='avatar'
        ) AS has_avatar
        FROM follows f JOIN users u ON u.id=f.channel
        WHERE f.user_id=%s ORDER BY u.name,u.id
    """, (ctx.uid,), many=True)
    by_id = {channel["id"]: channel for channel in channels}
    for channel in channels:
        channel["new_count"] = 0
    videos = ctx.videos("v.owner=ANY(%s)", (list(by_id),))
    seen = {row["video"] for row in query(ctx.cursor,
        "SELECT video FROM viewing_history WHERE user_id=%s", (ctx.uid,), many=True)}
    new_ids = []
    for video in videos:
        channel = by_id.get(video["owner"])
        if channel and video["published_at"] >= channel["followed_at"] and video["id"] not in seen:
            channel["new_count"] += 1
            new_ids.append(video["id"])
    channels.sort(key=lambda channel: channel["new_count"] == 0)
    return {"channels": channels, "videos": videos, "new_ids": new_ids}


@api.get("/recommendations", tags=["Видео"], response_model=list[VideoCard])
def recommendations(ctx: Context = Db):
    if not ctx.uid:
        return ctx.videos()[:48]
    rows = query(ctx.cursor, """
        SELECT v.owner,v.is_short,
               ((l.user_id IS NOT NULL)::int * 3 + (h.user_id IS NOT NULL)::int) AS weight
        FROM videos v
        LEFT JOIN likes l ON l.video=v.id AND l.user_id=%s
        LEFT JOIN viewing_history h ON h.video=v.id AND h.user_id=%s
        WHERE v.owner<>%s AND v.hidden=0
          AND (v.private=0 OR EXISTS (SELECT 1 FROM grants g WHERE g.video=v.id AND g.user_id=%s))
          AND (l.user_id IS NOT NULL OR h.user_id IS NOT NULL)
    """, (ctx.uid, ctx.uid, ctx.uid, ctx.uid), many=True)
    creators = {row["channel"]: 4 for row in query(ctx.cursor,
        "SELECT channel FROM follows WHERE user_id=%s", (ctx.uid,), many=True)}
    formats = {False: 0, True: 0}
    for row in rows:
        creators[row["owner"]] = creators.get(row["owner"], 0) + row["weight"]
        formats[row["is_short"]] += row["weight"]
    preferred_format = max(formats, key=formats.get) if formats[True] != formats[False] else None
    candidates = ctx.videos("""
        v.owner<>%s AND NOT EXISTS (
            SELECT 1 FROM viewing_history h WHERE h.video=v.id AND h.user_id=%s
        )
    """, (ctx.uid, ctx.uid))
    candidates.sort(key=lambda video: min(12, creators.get(video["owner"], 0)) +
                    int(video["is_short"] == preferred_format), reverse=True)
    return candidates[:48]


@api.get("/shorts", tags=["Видео"], response_model=list[VideoCard])
def shorts(ctx: Context = Db):
    return ctx.videos("v.is_short")


@api.get("/videos/{video_id}", tags=["Видео"], response_model=VideoDetails, response_model_exclude_none=True)
def video_details(video_id: str, ctx: Context = Db):
    video = dict(ctx.video(video_id))
    video["comments"] = query(ctx.cursor, """
        SELECT c.id,c.body,u.name FROM comments c JOIN users u ON u.id=c.user_id
        WHERE c.video=%s ORDER BY c.id DESC
    """, (video_id,), many=True)
    video["likes"] = query(ctx.cursor, "SELECT count(*) AS count FROM likes WHERE video=%s", (video_id,))["count"]
    video["liked"] = bool(query(ctx.cursor, "SELECT 1 FROM likes WHERE video=%s AND user_id=%s", (video_id, ctx.uid)))
    if video["owner"] == ctx.uid:
        video["grants"] = [r["name"] for r in query(ctx.cursor, """
            SELECT u.name FROM grants g JOIN users u ON u.id=g.user_id WHERE g.video=%s ORDER BY u.name
        """, (video_id,), many=True)]
    if ctx.uid:
        progress = query(ctx.cursor, "SELECT position_seconds FROM viewing_history WHERE user_id=%s AND video=%s",
                         (ctx.uid, video_id))
        video["position_seconds"] = progress["position_seconds"] if progress else 0
        video["folders"] = [row["folder"] for row in query(ctx.cursor,
            "SELECT folder FROM library_entries WHERE user_id=%s AND video=%s", (ctx.uid, video_id), many=True)]
    video["support_enabled"] = bool(query(ctx.cursor,
        "SELECT 1 FROM creator_support WHERE user_id=%s AND enabled", (video["owner"],)))
    return video


@api.get("/videos/{video_id}/poster", tags=["Видео"], response_class=FileResponse,
         responses={200: {"content": {"image/jpeg": {}}}})
@api.head("/videos/{video_id}/poster", include_in_schema=False)
def poster(video_id: str, request: Request, ctx: Context = Db):
    ctx.video(video_id)
    cover = query(ctx.cursor, "SELECT image FROM video_covers WHERE video=%s", (video_id,))
    if cover:
        image = bytes(cover["image"])
        return Response(image if request.method != "HEAD" else b"", media_type="image/jpeg",
                        headers={"Content-Length": str(len(image))})
    file = MEDIA / video_id / "poster.jpg"
    if not file.is_file():
        raise HTTPException(404, "Превью не найдено")
    return FileResponse(file, media_type="image/jpeg")


def chunks(file, start, count):
    with file.open("rb") as source:
        source.seek(start)
        while count:
            block = source.read(min(count, 65536))
            if not block:
                break
            yield block
            count -= len(block)


@api.get("/videos/{video_id}/stream", tags=["Видео"], response_class=StreamingResponse,
         responses={200: {"content": {"video/mp4": {}}}, 206: {"description": "Диапазон байтов"}, 416: {"description": "Диапазон недоступен"}})
@api.head("/videos/{video_id}/stream", include_in_schema=False)
def stream(video_id: str, request: Request, ctx: Context = Db):
    ctx.video(video_id)
    file = MEDIA / video_id / "video.mp4"
    if not file.is_file():
        raise HTTPException(404, "Файл не найден")
    size = file.stat().st_size
    start, end, status = 0, size - 1, 200
    headers = {"Accept-Ranges": "bytes"}
    if requested := request.headers.get("range"):
        match = re.fullmatch(r"bytes=(\d{0,20})-(\d{0,20})", requested)
        if match and any(match.groups()):
            left, right = match.groups()
            if left:
                start = int(left)
                if right:
                    end = min(end, int(right))
            else:
                start = max(0, size - int(right))
        else:
            start = size
        if start > end:
            return Response(status_code=416, headers=headers | {"Content-Range": f"bytes */{size}"})
        headers["Content-Range"] = f"bytes {start}-{end}/{size}"
        status = 206
    length = end - start + 1
    headers["Content-Length"] = str(length)
    if request.method == "HEAD":
        return Response(status_code=status, headers=headers, media_type="video/mp4")
    return StreamingResponse(chunks(file, start, length), status_code=status, headers=headers, media_type="video/mp4")


def save_video(cursor, video_id, title, description, private, uid, is_short, duration, source_digest, media_digest):
    cursor.execute("SELECT pg_advisory_xact_lock(741629)")
    cursor.execute("""
        INSERT INTO videos(id,owner,title,description,private,created,is_short,duration_seconds,source_sha256,media_sha256)
        VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
    """, (video_id, uid, title, description, int(private), int(time.time()), is_short, duration, source_digest, media_digest))
    cursor.execute("""
        INSERT INTO copyright_matches(video,reference)
        SELECT %s,r.video FROM copyright_references r JOIN videos v ON v.id=r.video
        WHERE r.active AND v.owner<>%s AND (v.source_sha256=%s OR v.media_sha256=%s)
    """, (video_id, uid, source_digest, media_digest))
    return cursor.rowcount


def upload_owner(token=Security(COOKIE)):
    conn = connect()
    try:
        with conn.cursor() as cursor:
            ctx = Context(cursor, token)
            ctx.require()
            return ctx.uid
    finally:
        conn.close()


@api.post("/upload", tags=["Видео"], status_code=202, response_model=UploadResult, openapi_extra={
    "requestBody": {"required": True, "content": {"application/octet-stream": {
        "schema": {"type": "string", "format": "binary"}
    }}}
})
async def upload(request: Request, title: str = Query(..., min_length=1, max_length=120),
                 description: str = Query("", max_length=2000), private: bool = False,
                 is_short: bool = Query(False, description="Вертикальный Shorts продолжительностью до 60 секунд"),
                 uid: int = Depends(upload_owner)):
    title = clean(title)
    if "\0" in description:
        raise HTTPException(400, "Некорректное описание")
    length = request.headers.get("content-length")
    if length is not None and (not length.isdecimal() or len(length) > 12 or not 0 < int(length) <= MAX_VIDEO):
        raise HTTPException(413, "Размер файла должен быть от 1 байта до 100 МиБ")
    video_id = secrets.token_hex(16)
    folder = MEDIA / video_id
    folder.mkdir()
    raw = folder / "upload"
    done = False
    try:
        size = 0
        source_hash = hashlib.sha256()
        with raw.open("wb") as target:
            async for block in request.stream():
                size += len(block)
                if size > MAX_VIDEO:
                    raise HTTPException(413, "Файл превышает 100 МиБ")
                source_hash.update(block)
                target.write(block)
        if not size:
            raise HTTPException(422, "Файл пуст")
        conn = connect()
        try:
            with conn, conn.cursor() as cursor:
                cursor.execute("""
                    INSERT INTO upload_jobs(id,owner,title,description,private,is_short,source_sha256)
                    VALUES(%s,%s,%s,%s,%s,%s,%s)
                """, (video_id, uid, title, description.strip(), private, is_short, source_hash.hexdigest()))
            done = True
        finally:
            conn.close()
        return {"id": video_id, "status": "processing"}
    finally:
        if not done:
            shutil.rmtree(folder, ignore_errors=True)


@api.get("/uploads/{video_id}", tags=["Видео"], response_model=UploadResult)
def upload_status(video_id: str, ctx: Context = Db):
    ctx.require()
    job = query(ctx.cursor, "SELECT id,status,error,copyright_matches FROM upload_jobs WHERE id=%s AND owner=%s",
                (video_id, ctx.uid))
    if not job:
        raise HTTPException(404, "Загрузка не найдена")
    return job


@api.post("/videos/{video_id}/like", tags=["Видео"])
def like(video_id: str, data: Toggle, ctx: Context = Db):
    ctx.require()
    ctx.video(video_id, lock=True)
    if data.enabled:
        ctx.cursor.execute("INSERT INTO likes VALUES(%s,%s) ON CONFLICT DO NOTHING", (video_id, ctx.uid))
    else:
        ctx.cursor.execute("DELETE FROM likes WHERE video=%s AND user_id=%s", (video_id, ctx.uid))
    ctx.commit()
    return {}


@api.post("/videos/{video_id}/comment", tags=["Видео"])
def comment(video_id: str, data: Comment, ctx: Context = Db):
    ctx.require()
    ctx.video(video_id, lock=True)
    ctx.cursor.execute("INSERT INTO comments(video,user_id,body) VALUES(%s,%s,%s)", (video_id, ctx.uid, clean(data.body)))
    ctx.commit()
    return {}


@api.post("/videos/{video_id}/report", tags=["Модерация"])
def report(video_id: str, data: Report, ctx: Context = Db):
    ctx.require()
    ctx.video(video_id, lock=True)
    ctx.cursor.execute("""
        INSERT INTO reports(video,user_id,reason) VALUES(%s,%s,%s)
        ON CONFLICT(video,user_id) DO UPDATE SET reason=excluded.reason,resolved=0
    """, (video_id, ctx.uid, clean(data.reason)))
    ctx.commit()
    return {}


@api.post("/videos/{video_id}/access", tags=["Видео"])
def access(video_id: str, data: Grant, ctx: Context = Db):
    ctx.require()
    video = ctx.video(video_id, lock=True)
    if video["owner"] != ctx.uid or not video["private"]:
        raise HTTPException(403, "Доступом управляет владелец приватного видео")
    user = query(ctx.cursor, "SELECT id FROM users WHERE name=%s", (clean(data.name),))
    if not user:
        raise HTTPException(404, "Пользователь не найден")
    if data.enabled:
        ctx.cursor.execute("INSERT INTO grants VALUES(%s,%s) ON CONFLICT DO NOTHING", (video_id, user["id"]))
    else:
        ctx.cursor.execute("DELETE FROM grants WHERE video=%s AND user_id=%s", (video_id, user["id"]))
    ctx.commit()
    return {}


@api.get("/channels/{channel_id}", tags=["Каналы"], response_model=ChannelView)
def channel(channel_id: int, ctx: Context = Db):
    owner = query(ctx.cursor, "SELECT id,name FROM users WHERE id=%s", (channel_id,))
    if not owner:
        raise HTTPException(404, "Канал не найден")
    playlists = query(ctx.cursor, "SELECT id,title FROM playlists WHERE owner=%s ORDER BY id DESC", (channel_id,), many=True)
    for playlist in playlists:
        playlist["videos"] = ctx.videos("v.id IN (SELECT video FROM playlist_videos WHERE playlist=%s)", (playlist["id"],))
    if channel_id != ctx.uid:
        playlists = [p for p in playlists if p["videos"]]
    followers = query(ctx.cursor, "SELECT count(*) AS count FROM follows WHERE channel=%s", (channel_id,))["count"]
    follow = query(ctx.cursor, "SELECT notifications_enabled FROM follows WHERE channel=%s AND user_id=%s", (channel_id, ctx.uid))
    return dict(owner) | {"images": image_kinds(ctx, channel_id), "videos": ctx.videos("v.owner=%s", (channel_id,)), "playlists": playlists,
                          "followers": followers, "following": bool(follow),
                          "notifications_enabled": bool(follow and follow["notifications_enabled"])}


@api.get("/u/{name}", tags=["Каналы"], response_model=ChannelView)
def public_profile(name: str, ctx: Context = Db):
    owner = query(ctx.cursor, "SELECT id FROM users WHERE name=%s", (clean(name),))
    if not owner:
        raise HTTPException(404, "Профиль не найден")
    return channel(owner["id"], ctx)


def image_kinds(ctx, user_id):
    return [row["kind"] for row in query(ctx.cursor,
        "SELECT kind FROM profile_images WHERE user_id=%s", (user_id,), many=True)]


@api.get("/profiles/{user_id}/image/{kind}", tags=["Профиль"], response_class=Response,
         responses={200: {"content": {"image/jpeg": {}}}})
def profile_image(user_id: int, kind: ImageKind, ctx: Context = Db):
    row = query(ctx.cursor, "SELECT image FROM profile_images WHERE user_id=%s AND kind=%s", (user_id, kind))
    if not row:
        raise HTTPException(404, "Изображение не найдено")
    return Response(bytes(row["image"]), media_type="image/jpeg")


def normalize_image(raw, dimensions):
    try:
        with Image.open(BytesIO(raw), formats=["JPEG", "PNG", "WEBP"]) as source:
            if source.width * source.height > 16_000_000:
                raise ValueError("Too many pixels")
            source = ImageOps.exif_transpose(source).convert("RGB")
            source.thumbnail(dimensions)
            normalized = BytesIO()
            source.save(normalized, format="JPEG", quality=86)
    except (UnidentifiedImageError, Image.DecompressionBombError, OSError, ValueError) as error:
        raise HTTPException(422, "Выберите корректное изображение JPEG, PNG или WebP до 16 Мп") from error
    return normalized.getvalue()


def save_profile_image(uid, kind, raw):
    image = normalize_image(raw, (512, 512) if kind == "avatar" else (1600, 700))
    conn = connect()
    try:
        with conn, conn.cursor() as cursor:
            cursor.execute("""
                INSERT INTO profile_images VALUES(%s,%s,%s)
                ON CONFLICT(user_id,kind) DO UPDATE SET image=excluded.image
            """, (uid, kind, image))
    finally:
        conn.close()


@api.post("/profile/image/{kind}", tags=["Профиль"], openapi_extra={
    "requestBody": {"required": True, "content": {"application/octet-stream": {
        "schema": {"type": "string", "format": "binary"}
    }}}
})
async def update_profile_image(kind: ImageKind, request: Request, uid: int = Depends(upload_owner)):
    await run_in_threadpool(save_profile_image, uid, kind, await read_image(request))
    return {}


async def read_image(request):
    data = bytearray()
    async for block in request.stream():
        if len(data) + len(block) > MAX_PROFILE_IMAGE:
            raise HTTPException(413, "Изображение должно быть не больше 5 МиБ")
        data.extend(block)
    return data


class ProfileView(BaseModel):
    images: list[ImageKind]
    history: list[VideoCard]
    folders: dict[str, list[VideoCard]]


@api.get("/profile", tags=["Профиль"], response_model=ProfileView)
def profile(ctx: Context = Db):
    ctx.require()
    history = ctx.videos("v.id IN (SELECT video FROM viewing_history WHERE user_id=%s)", (ctx.uid, ctx.uid),
                         order="(SELECT watched_at FROM viewing_history h WHERE h.video=v.id AND h.user_id=%s) DESC,v.id")
    folders = {
        key: ctx.videos("v.id IN (SELECT video FROM library_entries WHERE user_id=%s AND folder=%s)", (ctx.uid, key))
        for key in ("saved", "later")
    }
    folders["own"] = ctx.videos("v.owner=%s", (ctx.uid,))
    folders["liked"] = ctx.videos("v.id IN (SELECT video FROM likes WHERE user_id=%s)", (ctx.uid,))
    folders["commented"] = ctx.videos("v.id IN (SELECT video FROM comments WHERE user_id=%s)", (ctx.uid,))
    return {"images": image_kinds(ctx, ctx.uid), "history": history, "folders": folders}


@api.post("/videos/{video_id}/view", tags=["Профиль"])
def record_view(video_id: str, ctx: Context = Db):
    ctx.require()
    ctx.video(video_id, lock=True)
    ctx.cursor.execute("""
        INSERT INTO viewing_history(user_id,video) VALUES(%s,%s)
        ON CONFLICT(user_id,video) DO UPDATE SET watched_at=now()
    """, (ctx.uid, video_id))
    ctx.commit()
    return {}


class Progress(BaseModel):
    viewer: int
    session_id: UUID
    sequence: int = Field(ge=1, le=2_000_000_000)
    position: float = Field(ge=0, le=86400)
    watched: float = Field(ge=0, le=86400)


@api.post("/videos/{video_id}/progress", tags=["Видео"])
def progress(video_id: str, data: Progress, ctx: Context = Db):
    ctx.require()
    if ctx.uid != data.viewer:
        raise HTTPException(409, "Аккаунт просмотра изменился")
    video = ctx.video(video_id)
    position = min(data.position, video["duration_seconds"] or data.position)
    accepted = query(ctx.cursor, """
        INSERT INTO playback_sessions VALUES (%s,%s,%s,%s,%s)
        ON CONFLICT (user_id,video,session_id) DO UPDATE SET
            sequence=excluded.sequence, watched_seconds=GREATEST(playback_sessions.watched_seconds,excluded.watched_seconds)
        WHERE playback_sessions.sequence<excluded.sequence
        RETURNING sequence
    """, (ctx.uid, video_id, str(data.session_id), data.sequence, data.watched))
    if accepted:
        ctx.cursor.execute("""
            INSERT INTO viewing_history(user_id,video,position_seconds) VALUES(%s,%s,%s)
            ON CONFLICT (user_id,video) DO UPDATE SET watched_at=now(),position_seconds=excluded.position_seconds
        """, (ctx.uid, video_id, position))
    ctx.commit()
    return {}


@api.post("/videos/{video_id}/library/{folder}", tags=["Профиль"])
def change_library(video_id: str, folder: Literal["saved", "later"], data: Toggle, ctx: Context = Db):
    ctx.require()
    if data.enabled:
        ctx.video(video_id, lock=True)
        ctx.cursor.execute("INSERT INTO library_entries VALUES(%s,%s,%s) ON CONFLICT DO NOTHING",
                           (ctx.uid, video_id, folder))
    else:
        ctx.cursor.execute("DELETE FROM library_entries WHERE user_id=%s AND video=%s AND folder=%s",
                           (ctx.uid, video_id, folder))
    ctx.commit()
    return {}


class VideoEdit(BaseModel):
    title: str = Field(min_length=1, max_length=120)
    description: str = Field(max_length=2000)
    private: bool


@api.get("/studio", tags=["Студия"], response_model=list[VideoCard])
def studio(ctx: Context = Db):
    ctx.require()
    return query(ctx.cursor, """
        SELECT v.*,u.name AS author FROM videos v JOIN users u ON u.id=v.owner
        WHERE v.owner=%s ORDER BY v.created DESC,v.id
    """, (ctx.uid,), many=True)


@api.post("/studio/videos/{video_id}", tags=["Студия"])
def edit_video(video_id: str, data: VideoEdit, ctx: Context = Db):
    ctx.require()
    if "\0" in data.description:
        raise HTTPException(400, "Некорректное описание")
    ctx.cursor.execute("UPDATE videos SET title=%s,description=%s,private=%s WHERE id=%s AND owner=%s",
                       (clean(data.title), data.description.strip(), int(data.private), video_id, ctx.uid))
    if not ctx.cursor.rowcount:
        raise HTTPException(404, "Видео не найдено в вашей студии")
    ctx.commit()
    return {}


@api.post("/channels/{channel_id}/follow", tags=["Каналы"])
def follow(channel_id: int, data: Toggle, ctx: Context = Db):
    ctx.require()
    if channel_id == ctx.uid or not query(ctx.cursor, "SELECT 1 FROM users WHERE id=%s", (channel_id,)):
        raise HTTPException(400, "Выберите канал другого автора")
    if data.enabled:
        ctx.cursor.execute("INSERT INTO follows(channel,user_id) VALUES(%s,%s) ON CONFLICT DO NOTHING", (channel_id, ctx.uid))
    else:
        ctx.cursor.execute("DELETE FROM follows WHERE channel=%s AND user_id=%s", (channel_id, ctx.uid))
    ctx.commit()
    return {}


@api.post("/channels/{channel_id}/notifications", tags=["Уведомления"])
def notification_setting(channel_id: int, data: Toggle, ctx: Context = Db):
    ctx.require()
    ctx.cursor.execute("UPDATE follows SET notifications_enabled=%s WHERE channel=%s AND user_id=%s",
                       (data.enabled, channel_id, ctx.uid))
    if not ctx.cursor.rowcount:
        raise HTTPException(404, "Сначала подпишитесь на канал")
    ctx.commit()
    return {}


class NotificationsView(BaseModel):
    unread: int
    videos: list[VideoCard]
    unread_ids: list[str]


@api.get("/notifications", tags=["Уведомления"], response_model=NotificationsView)
def notifications(ctx: Context = Db):
    ctx.require()
    items = ctx.videos("""
        EXISTS (SELECT 1 FROM follows f WHERE f.user_id=%s AND f.channel=v.owner
                AND f.notifications_enabled AND v.published_at>=f.followed_at)
    """, (ctx.uid,), order="v.published_at DESC,v.id")[:100]
    read = {row["video"] for row in query(ctx.cursor,
        "SELECT video FROM notification_reads WHERE user_id=%s", (ctx.uid,), many=True)}
    unread = [v["id"] for v in items if v["id"] not in read]
    return {"videos": items, "unread": len(unread), "unread_ids": unread}


class NotificationRead(BaseModel):
    ids: list[str] = Field(max_items=100)


@api.post("/notifications/read", tags=["Уведомления"])
def read_notifications(data: NotificationRead, ctx: Context = Db):
    allowed = set(notifications(ctx)["unread_ids"])
    for video_id in allowed.intersection(data.ids):
        ctx.cursor.execute("INSERT INTO notification_reads VALUES (%s,%s) ON CONFLICT DO NOTHING",
                           (ctx.uid, video_id))
    ctx.commit()
    return {}


class AnalyticsItem(BaseModel):
    id: str
    views: int
    watch_seconds: float
    unique_viewers: int


@api.get("/studio/analytics", tags=["Студия"], response_model=list[AnalyticsItem])
def studio_analytics(ctx: Context = Db):
    ctx.require()
    return query(ctx.cursor, """
        SELECT v.id, count(p.session_id) AS views, COALESCE(sum(p.watched_seconds),0) AS watch_seconds,
               count(DISTINCT p.user_id) AS unique_viewers
        FROM videos v LEFT JOIN playback_sessions p ON p.video=v.id
             AND p.watched_seconds>=1 AND p.user_id<>v.owner
        WHERE v.owner=%s GROUP BY v.id
    """, (ctx.uid,), many=True)


def write_video_cover(uid, video_id, data):
    image = normalize_image(data, (1600, 1600))
    conn = connect()
    try:
        with conn, conn.cursor() as cursor:
            cursor.execute("""
                INSERT INTO video_covers(video,image)
                SELECT id,%s FROM videos WHERE id=%s AND owner=%s
                ON CONFLICT(video) DO UPDATE SET image=excluded.image
            """, (image, video_id, uid))
            if not cursor.rowcount:
                raise HTTPException(404, "Видео не найдено в вашей студии")
    finally:
        conn.close()


@api.post("/studio/videos/{video_id}/cover", tags=["Студия"])
async def update_video_cover(video_id: str, request: Request, uid: int = Depends(upload_owner)):
    await run_in_threadpool(write_video_cover, uid, video_id, await read_image(request))
    return {}


@api.post("/playlists", tags=["Каналы"])
def create_playlist(data: Playlist, ctx: Context = Db):
    ctx.require()
    ctx.cursor.execute("INSERT INTO playlists(owner,title) VALUES(%s,%s)", (ctx.uid, clean(data.title)))
    ctx.commit()
    return {}


@api.post("/playlists/{playlist_id}/videos", tags=["Каналы"])
def playlist_video(playlist_id: int, data: PlaylistVideo, ctx: Context = Db):
    ctx.require()
    if not query(ctx.cursor, "SELECT 1 FROM playlists WHERE id=%s AND owner=%s", (playlist_id, ctx.uid)):
        raise HTTPException(404, "Плейлист не найден")
    if ctx.video(data.video, lock=True)["owner"] != ctx.uid:
        raise HTTPException(403, "В плейлист канала добавляются видео автора")
    if data.enabled:
        ctx.cursor.execute("INSERT INTO playlist_videos VALUES(%s,%s) ON CONFLICT DO NOTHING", (playlist_id, data.video))
    else:
        ctx.cursor.execute("DELETE FROM playlist_videos WHERE playlist=%s AND video=%s", (playlist_id, data.video))
    ctx.commit()
    return {}


@api.get("/moderation", tags=["Модерация"], response_model=list[ReportView])
def reports(ctx: Context = Db):
    ctx.require(STAFF)
    return query(ctx.cursor, """
        SELECT r.id,r.video,r.reason,r.resolved,v.hidden,
               CASE WHEN v.private=0 THEN v.title ELSE 'Приватное видео' END AS title
        FROM reports r JOIN videos v ON v.id=r.video ORDER BY r.resolved,r.id DESC
    """, many=True)


@api.post("/moderation/{report_id}", tags=["Модерация"])
def moderate(report_id: int, data: Decision, ctx: Context = Db):
    ctx.require(STAFF)
    report = query(ctx.cursor, "SELECT video FROM reports WHERE id=%s", (report_id,))
    if not report:
        raise HTTPException(404, "Жалоба не найдена")
    if data.action == "dismiss":
        ctx.cursor.execute("UPDATE reports SET resolved=1 WHERE id=%s", (report_id,))
    else:
        ctx.cursor.execute("UPDATE videos SET hidden=%s WHERE id=%s", (int(data.action == "hide"), report["video"]))
        ctx.cursor.execute("UPDATE reports SET resolved=1 WHERE video=%s", (report["video"],))
    ctx.commit()
    return {}


@api.get("/users", tags=["Администрирование"], response_model=list[Account])
def users(ctx: Context = Db):
    ctx.require(("admin",))
    return query(ctx.cursor, "SELECT id,name,role FROM users ORDER BY id", many=True)


@api.post("/users/{user_id}/role", tags=["Администрирование"])
def change_role(user_id: int, data: RoleChange, ctx: Context = Db):
    ctx.require(("admin",))
    if user_id == ctx.uid:
        raise HTTPException(400, "Выберите другого пользователя")
    ctx.cursor.execute("UPDATE users SET role=%s WHERE id=%s", (data.role, user_id))
    if not ctx.cursor.rowcount:
        raise HTTPException(404, "Пользователь не найден")
    ctx.commit()
    return {}


def file_digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


@api.get("/studio/copyright", tags=["Авторские права"])
def copyright_studio(ctx: Context = Db):
    ctx.require()
    references = query(ctx.cursor, """
        SELECT v.id,v.title,COALESCE(r.active,FALSE) AS active
        FROM videos v LEFT JOIN copyright_references r ON r.video=v.id
        WHERE v.owner=%s ORDER BY v.created DESC,v.id
    """, (ctx.uid,), many=True)
    matches = query(ctx.cursor, """
        SELECT m.id,v.title,m.status FROM copyright_matches m JOIN videos v ON v.id=m.video
        WHERE v.owner=%s ORDER BY m.id DESC
    """, (ctx.uid,), many=True)
    return {"references": references, "matches": matches}


@api.post("/studio/copyright/{video_id}", tags=["Авторские права"])
def copyright_reference(video_id: str, data: Toggle, ctx: Context = Db):
    ctx.require()
    row = query(ctx.cursor, "SELECT media_sha256 FROM videos WHERE id=%s AND owner=%s", (video_id, ctx.uid))
    if not row:
        raise HTTPException(404, "Видео не найдено в вашей студии")
    digest = row["media_sha256"]
    if data.enabled and not digest:
        try:
            digest = file_digest(MEDIA / video_id / "video.mp4")
        except OSError as error:
            raise HTTPException(404, "Файл видео недоступен") from error
    ctx.cursor.execute("SELECT pg_advisory_xact_lock(741629)")
    if data.enabled:
        ctx.cursor.execute("UPDATE videos SET media_sha256=%s WHERE id=%s", (digest, video_id))
    ctx.cursor.execute("""
        INSERT INTO copyright_references VALUES(%s,%s)
        ON CONFLICT(video) DO UPDATE SET active=excluded.active
    """, (video_id, data.enabled))
    ctx.commit()
    return {}


class CopyrightDecision(BaseModel):
    status: Literal["confirmed", "dismissed"]


@api.get("/moderation/copyright", tags=["Авторские права"])
def copyright_queue(ctx: Context = Db):
    ctx.require(STAFF)
    return query(ctx.cursor, """
        SELECT m.id,m.video,m.reference AS reference_id,m.status,
               v.private=0 AND v.hidden=0 AS video_visible,
               r.private=0 AND r.hidden=0 AS reference_visible,
               CASE WHEN v.private=0 THEN v.title ELSE 'Приватное видео' END AS title,
               CASE WHEN r.private=0 THEN r.title ELSE 'Приватный эталон' END AS reference
        FROM copyright_matches m JOIN videos v ON v.id=m.video JOIN videos r ON r.id=m.reference
        ORDER BY (m.status='pending') DESC,m.id DESC
    """, many=True)


@api.post("/moderation/copyright/{match_id}", tags=["Авторские права"])
def decide_copyright(match_id: int, data: CopyrightDecision, ctx: Context = Db):
    ctx.require(STAFF)
    ctx.cursor.execute("UPDATE copyright_matches SET status=%s WHERE id=%s AND status='pending'",
                       (data.status, match_id))
    if not ctx.cursor.rowcount:
        raise HTTPException(409, "Совпадение уже рассмотрено или недоступно")
    ctx.commit()
    return {}


def demo_wallet(ctx):
    return query(ctx.cursor, """
        SELECT 100 + COALESCE(sum(amount) FILTER (WHERE recipient=%s),0)
                   - COALESCE(sum(amount) FILTER (WHERE sender=%s),0) AS balance,
               COALESCE(sum(amount) FILTER (WHERE recipient=%s),0) AS received,
               COALESCE(sum(amount) FILTER (WHERE sender=%s),0) AS sent
        FROM demo_tips WHERE sender=%s OR recipient=%s
    """, (ctx.uid,) * 6)


@api.get("/studio/monetization", tags=["Монетизация"])
def monetization(ctx: Context = Db):
    ctx.require()
    setting = query(ctx.cursor, "SELECT enabled FROM creator_support WHERE user_id=%s", (ctx.uid,))
    activity = query(ctx.cursor, """
        SELECT t.id,t.amount,t.created,t.recipient=%s AS incoming,
               CASE WHEN v.owner=%s OR (v.hidden=0 AND (v.private=0 OR EXISTS (
                    SELECT 1 FROM grants g WHERE g.video=v.id AND g.user_id=%s
               ))) THEN v.title ELSE 'Недоступное видео' END AS title
        FROM demo_tips t JOIN videos v ON v.id=t.video
        WHERE t.sender=%s OR t.recipient=%s ORDER BY t.id DESC LIMIT 30
    """, (ctx.uid,) * 5, many=True)
    return dict(demo_wallet(ctx)) | {"enabled": bool(setting and setting["enabled"]), "activity": activity}


@api.post("/studio/monetization", tags=["Монетизация"])
def set_monetization(data: Toggle, ctx: Context = Db):
    ctx.require()
    ctx.cursor.execute("""
        INSERT INTO creator_support VALUES(%s,%s)
        ON CONFLICT(user_id) DO UPDATE SET enabled=excluded.enabled
    """, (ctx.uid, data.enabled))
    ctx.commit()
    return {}


class DemoTip(BaseModel):
    amount: int = Field(ge=1, le=100)
    request_id: UUID


@api.post("/videos/{video_id}/support", tags=["Монетизация"])
def support_creator(video_id: str, data: DemoTip, ctx: Context = Db):
    ctx.require()
    ctx.cursor.execute("SELECT id FROM users WHERE id=%s FOR NO KEY UPDATE", (ctx.uid,))
    prior = query(ctx.cursor, "SELECT video,amount FROM demo_tips WHERE sender=%s AND request_id=%s",
                  (ctx.uid, str(data.request_id)))
    if prior:
        if prior["video"] != video_id or prior["amount"] != data.amount:
            raise HTTPException(409, "Этот идентификатор уже использован")
        return {"balance": demo_wallet(ctx)["balance"]}
    video = ctx.video(video_id, lock=True)
    if video["owner"] == ctx.uid:
        raise HTTPException(400, "Нельзя отправить баллы себе")
    setting = query(ctx.cursor, "SELECT enabled FROM creator_support WHERE user_id=%s FOR SHARE", (video["owner"],))
    if not setting or not setting["enabled"]:
        raise HTTPException(409, "Автор не принимает поддержку")
    balance = demo_wallet(ctx)["balance"]
    if balance < data.amount:
        raise HTTPException(409, "Недостаточно демонстрационных баллов")
    ctx.cursor.execute("INSERT INTO demo_tips(sender,recipient,video,amount,request_id) VALUES(%s,%s,%s,%s,%s)",
                       (ctx.uid, video["owner"], video_id, data.amount, str(data.request_id)))
    ctx.commit()
    return {"balance": balance - data.amount}


def live_account(token):
    conn = connect()
    try:
        with conn.cursor() as cursor:
            return Context(cursor, token).user
    finally:
        conn.close()


@api.get("/health", tags=["Система"])
def health(ctx: Context = Db):
    ctx.cursor.execute("SELECT 1")
    return {"status": "ok"}


app.state.live_account = live_account
app.include_router(api)
app.include_router(live_router)


@app.get("/", include_in_schema=False)
def home():
    return FileResponse(ROOT / "web" / "index.html")


@app.get("/app.js", include_in_schema=False)
def script():
    return FileResponse(ROOT / "web" / "app.js", media_type="text/javascript")


@app.get("/style.css", include_in_schema=False)
def styles():
    return FileResponse(ROOT / "web" / "style.css", media_type="text/css")


def promote(name):
    conn = connect()
    try:
        with conn, conn.cursor() as cursor:
            cursor.execute("UPDATE users SET role='admin' WHERE name=%s", (name,))
            if not cursor.rowcount:
                sys.exit("Сначала зарегистрируйте этот аккаунт.")
    finally:
        conn.close()
    print("Роль администратора назначена.")


if __name__ == "__main__":
    if len(sys.argv) == 3 and sys.argv[1] == "admin":
        promote(sys.argv[2])
    else:
        import uvicorn

        uvicorn.run(app, host=os.environ.get("HOST", "127.0.0.1"),
                    port=int(os.environ.get("PORT", "8000")), ws="websockets", ws_max_size=65536, access_log=False)
