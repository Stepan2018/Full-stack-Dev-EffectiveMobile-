"""Generate original synthetic clips and publish them via the local API."""
import argparse
import json
import os
import secrets
import subprocess
import time
from http.cookiejar import CookieJar
from urllib.parse import urlencode
from urllib.request import Request, HTTPCookieProcessor, build_opener


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--shorts", action="store_true", help="Опубликовать вертикальные Shorts")
    args = parser.parse_args()
    base = f"http://127.0.0.1:{int(os.environ.get('PORT', '8000'))}/api"
    client = build_opener(HTTPCookieProcessor(CookieJar()))
    name, password = register(client, base, "studio")
    viewer = build_opener(HTTPCookieProcessor(CookieJar()))
    viewer_name, viewer_password = register(viewer, base, "viewer")
    clips = [
        ("Малиновая орбита", "0x601731", "0xf16686", "0xffd7dd"),
        ("Ночной сигнал", "0x181937", "0x9168ff", "0x4ed8f2"),
        ("Тёплый горизонт", "0x4c251d", "0xff995f", "0xffe1a0"),
    ]
    if args.shorts:
        clips = [
            ("Малиновая орбита", "0x601731", "0xf16686", "0xffd7dd"),
            ("Ночной сигнал", "0x181937", "0x9168ff", "0x4ed8f2"),
            ("Тёплый горизонт", "0x4c251d", "0xff995f", "0xffe1a0"),
            ("Мятная волна", "0x183832", "0x5de7bc", "0xbfffe9"),
        ]
    size = "360x640" if args.shorts else "640x360"
    for title, background, accent, light in clips:
        pattern = (
            f"gradients=s={size}:r=24:d=4:c0={background}:c1={accent}:"
            f"c2={light}:n=3:type=radial:speed=0.09"
        )
        video = subprocess.check_output([
            "ffmpeg", "-nostdin", "-loglevel", "error", "-f", "lavfi", "-i", pattern,
            "-filter_threads", "1", "-c:v", "libx264", "-threads", "2", "-pix_fmt", "yuv420p",
            "-movflags", "+frag_keyframe+empty_moov", "-f", "mp4", "pipe:1",
        ])
        query = urlencode({"title": title, "description": "Оригинальная процедурная анимация для демонстрации KinoFlow.",
                           "is_short": int(args.shorts)})
        with client.open(Request(base + "/upload?" + query, video, {"Content-Type": "video/mp4"}), timeout=30) as response:
            video_id = json.load(response)["id"]
        wait_for_video(client, base, video_id)
        post(viewer, base + f"/videos/{video_id}/comment", {"body": f"Демо-комментарий к ролику «{title}»."})
        post(viewer, base + f"/videos/{video_id}/like", {"enabled": True})
        print(f"Опубликовано: {title}", flush=True)
    print(f"Автор: {name} / {password}\nЗритель: {viewer_name} / {viewer_password}")


def post(client, url, data):
    request = Request(url, json.dumps(data).encode(), {"Content-Type": "application/json"})
    with client.open(request, timeout=15) as response:
        return json.load(response)


def register(client, base, prefix):
    name = prefix + "-" + secrets.token_hex(4)
    password = secrets.token_urlsafe(16)
    post(client, base + "/register", {"name": name, "password": password})
    return name, password


def wait_for_video(client, base, video_id, timeout=240):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        with client.open(base + f"/uploads/{video_id}", timeout=15) as response:
            result = json.load(response)
        if result["status"] == "ready":
            return result
        if result["status"] == "failed":
            raise RuntimeError(result["error"])
        time.sleep(0.5)
    raise TimeoutError("Видео не обработано. Проверьте журнал воркера.")


if __name__ == "__main__":
    main()
